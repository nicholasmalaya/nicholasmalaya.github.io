#!/usr/bin/env bash
# Author: Nico Trost
# Modified by: Noah Wolfe

#set -x #echo on

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color
BUILD_SCRIPT=hmake-bp.sh

# #################################################
# helper functions
# #################################################
function display_help()
{
  echo "HACC build helper script"
  echo "./install "
  echo "    [-h|--help] prints this help message"
  echo "    [-i|--install] install after build"
  echo "    [-d|--dependencies] install dependencies"
  echo "    [-g|--debug] Set build type to Debug (otherwise build Release)"
  echo "    [--with-rocm=<dir>] Path to ROCm install (Default: /opt/rocm)"
  echo "    [--with-mpi=<dir>] Path to external MPI install (Default: clone+build OpenMPI v4.0.5 in tpl/)"
  echo "    [--with-fftw=<dir>] Path to external FFTW install (Default: clone+build FFTW v3.3.7 in tpl/)"
  echo "    [--gpu-aware-mpi] MPI library supports GPU-aware communication (Default: false)"
  echo "    [--verbose-print] Verbose output during HACC setup (Default: true)"
  echo "    [--progress-report] Print progress report to terminal during HACC run (Default: true)"
  echo "    [--detailed-timing] Record detailed timers during HACC run (Default: true)"
}

# This function is helpful for dockerfiles that do not have sudo installed, but the default user is root
# true is a system command that completes successfully, function returns success
# prereq: ${ID} must be defined before calling
supported_distro( )
{
  if [ -z ${ID+foo} ]; then
    printf "supported_distro(): \$ID must be set\n"
    exit 2
  fi

  case "${ID}" in
    ubuntu|centos|rhel|fedora|sles)
        true
        ;;
    *)  printf "This script is currently supported on Ubuntu, CentOS, RHEL, Fedora and SLES\n"
        exit 2
        ;;
  esac
}

# This function is helpful for dockerfiles that do not have sudo installed, but the default user is root
check_exit_code( )
{
  if (( $? != 0 )); then
    exit $?
  fi
}

# This function is helpful for dockerfiles that do not have sudo installed, but the default user is root
elevate_if_not_root( )
{
  local uid=$(id -u)

  if (( ${uid} )); then
    sudo $@
    check_exit_code
  else
    $@
    check_exit_code
  fi
}

# Take an array of packages as input, and install those packages with 'apt' if they are not already installed
install_apt_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    if [[ $(dpkg-query --show --showformat='${db:Status-Abbrev}\n' ${package} 2> /dev/null | grep -q "ii"; echo $?) -ne 0 ]]; then
      printf "\033[32mInstalling \033[33m${package}\033[32m from distro package manager\033[0m\n"
      elevate_if_not_root apt install -y --no-install-recommends ${package}
    fi
  done
}

# Take an array of packages as input, and install those packages with 'yum' if they are not already installed
install_yum_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    if [[ $(yum list installed ${package} &> /dev/null; echo $? ) -ne 0 ]]; then
      printf "\033[32mInstalling \033[33m${package}\033[32m from distro package manager\033[0m\n"
      elevate_if_not_root yum -y --nogpgcheck install ${package}
    fi
  done
}

# Take an array of packages as input, and install those packages with 'dnf' if they are not already installed
install_dnf_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    if [[ $(dnf list installed ${package} &> /dev/null; echo $? ) -ne 0 ]]; then
      printf "\033[32mInstalling \033[33m${package}\033[32m from distro package manager\033[0m\n"
      elevate_if_not_root dnf install -y ${package}
    fi
  done
}

# Take an array of packages as input, and install those packages with 'zypper' if they are not already installed
install_zypper_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    if [[ $(rpm -q ${package} &> /dev/null; echo $? ) -ne 0 ]]; then
      printf "\033[32mInstalling \033[33m${package}\033[32m from distro package manager\033[0m\n"
      elevate_if_not_root zypper -n --no-gpg-checks install ${package}
    fi
  done
}

# Take an array of packages as input, and delegate the work to the appropriate distro installer
# prereq: ${ID} must be defined before calling
install_packages( )
{
  if [ -z ${ID+foo} ]; then
    printf "install_packages(): \$ID must be set\n"
    exit 2
  fi

  # dependencies needed for executable to build
  local library_dependencies_ubuntu=( "make" "libnuma-dev" "pkg-config" "autoconf" "libtool" "automake" "m4" )
  local library_dependencies_centos=( "make" "gcc-c++" "rpm-build" "epel-release" "numactl-libs" "autoconf" "libtool" "automake" "m4"  )
  local library_dependencies_fedora=( "make" "gcc-c++" "libcxx-devel" "rpm-build" "numactl-libs"  "autoconf" "libtool" "automake" "m4"  )
  local library_dependencies_sles=(   "make" "gcc-c++" "libcxxtools9" "rpm-build" "libnuma-devel" "autoconf" "libtool" "automake" "m4"  )

  if [[ "${with_rocm}" == /opt/rocm ]]; then
    library_dependencies_ubuntu+=("rocm-dev")
    library_dependencies_centos+=("rocm-dev")
    library_dependencies_fedora+=("rocm-dev")
    library_dependencies_sles+=("rocm-dev")
  fi

  case "${ID}" in
    ubuntu)
      elevate_if_not_root apt update
      install_apt_packages "${library_dependencies_ubuntu[@]}"

      ;;

    centos|rhel)
#     yum -y update brings *all* installed packages up to date
#     without seeking user approval
#     elevate_if_not_root yum -y update
      install_yum_packages "${library_dependencies_centos[@]}"

      ;;

    fedora)
#     elevate_if_not_root dnf -y update
      install_dnf_packages "${library_dependencies_fedora[@]}"

      ;;

    sles)
#     elevate_if_not_root zypper -y update
      install_zypper_packages "${library_dependencies_sles[@]}"

       ;;
    *)
      echo "This script is currently supported on Ubuntu, CentOS, RHEL, Fedora and SLES"
      exit 2
      ;;
  esac
}

check_apt_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    dpkg-query -W $package > /dev/null
    if [ $? -eq 1 ]; then
      printf "\033[31mRequired package \033[33m${package}\033[31m is not installed.\033[0m\n"
      printf "\033[31mPlease install required package or disable corresponding HPCG build option.\033[0m\n"
      exit 2
    fi
  done
}

check_yum_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    rpm -q $package > /dev/null
    if [ $? -eq 1 ]; then
      printf "\033[31mRequired package \033[33m${package}\033[31m is not installed.\033[0m\n"
      printf "\033[31mPlease install required package or disable corresponding HPCG build option.\033[0m\n"
      exit 2
    fi
  done
}

check_dnf_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    rpm -q $package > /dev/null
    if [ $? -eq 1 ]; then
      printf "\033[31mRequired package \033[33m${package}\033[31m is not installed.\033[0m\n"
      printf "\033[31mPlease install required package or disable corresponding HPCG build option.\033[0m\n"
      exit 2
    fi
  done
}

check_zypper_packages( )
{
  package_dependencies=("$@")
  for package in "${package_dependencies[@]}"; do
    rpm -q $package > /dev/null
    if [ $? -eq 1 ]; then
      printf "\033[31mRequired package \033[33m${package}\033[31m is not installed.\033[0m\n"
      printf "\033[31mPlease install required package or disable corresponding HPCG build option.\033[0m\n"
      exit 2
    fi
  done
}

check_packages( )
{
  if [ -z ${ID+foo} ]; then
    printf "check_packages(): \$ID must be set\n"
    exit 2
  fi

  package_dependency=("$@")

  if [[ "$package_dependency" == omp ]]; then
    local build_dependencies_ubuntu=( "libomp-dev" )
    local build_dependencies_centos=( "libgomp" )
    local build_dependencies_fedora=( "libgomp" )
    local build_dependencies_sles=( "libgomp1" )
  fi

  case "${ID}" in
    ubuntu)
      check_apt_packages "${build_dependencies_ubuntu[@]}"
      ;;
    centos|rhel)
      check_yum_packages "${build_dependencies_centos[@]}"
      ;;
    fedora)
      check_dnf_packages "${build_dependencies_fedora[@]}"
      ;;
    sles)
      check_zypper_packages "${build_dependencies_sles[@]}"
      ;;
    *)
      echo "This script is currently supported on Ubuntu, CentOS, RHEL and Fedora"
      exit 2
      ;;
  esac
}

# Clone and build FFTW in hacc/tpl
install_fftw( )
{
  if [ ! -d "./tpl/fftw" ]; then
    mkdir -p tpl && cd tpl
    wget https://fftw.org/pub/fftw/fftw-3.3.7.tar.gz
    tar -xvf fftw-3.3.7.tar.gz
    rm fftw-3.3.7.tar.gz; mv fftw-3.3.7 fftw; cd fftw; mkdir build; cd build
    echo $PWD
    export LD_LIBRARY_PATH=$PWD/../../${mpi_vendor}/install/lib:$LD_LIBRARY_PATH
    export PATH=$PWD/../../${mpi_vendor}/install/bin:$PATH
    ../configure --enable-mpi --enable-openmp --prefix=$PWD/../ |& tee config.log
    make -j$(nproc); make install; cd ../../..
  fi
}

# Clone and build OpenMPI+UCX in hacc/tpl
install_openmpi( )
{
  if [ ! -d "./tpl/ucx" ]; then
    echo "BUILDING UCX"
    mkdir -p tpl && cd tpl
    git clone --branch v1.8.1 https://github.com/openucx/ucx.git ucx
    cd ucx; ./autogen.sh; ./autogen.sh #why do we have to run this twice?
    mkdir build; cd build
    ../contrib/configure-opt --prefix=${PWD}/../ --with-rocm=${with_rocm} --without-knem --without-cuda
    make -j$(nproc); make install; cd ../../..
  fi

  if [ ! -d "./tpl/openmpi" ]; then
    echo "BUILDING OPENMPI"
    mkdir -p tpl && cd tpl
    git clone --branch v4.0.5 https://github.com/open-mpi/ompi.git openmpi
    cd openmpi; ./autogen.pl; mkdir build; cd build
    ../configure --prefix=${PWD}/../install --with-ucx=${PWD}/../../ucx --without-verbs --enable-mpi-cxx --enable-mpi1-compatibility --enable-mpi-thread-multiple
    make -j$(nproc); make install; cd ../../..
  fi
}

install_mpich( )
{
  if [ ! -d "./tpl/autotools" ]; then
    mkdir -p tpl && cd tpl
    mkdir -p autotools && cd autotools
    if [ ! -d "./autoconf" ]; then
      wget http://ftp.gnu.org/gnu/autoconf/autoconf-2.69.tar.gz
      tar -xvf autoconf-2.69.tar.gz
      rm autoconf-2.69.tar.gz; cd autoconf-2.69; mkdir build; cd build
      ../configure --prefix=$PWD/../../install
      make -j
      make install
      cd ../..
    fi
    if [ ! -d "./automake" ]; then
      wget http://ftp.gnu.org/gnu/automake/automake-1.15.tar.gz
      tar -xvf automake-1.15.tar.gz
      rm automake-1.15.tar.gz; cd automake-1.15; mkdir build; cd build
      ../configure --prefix=$PWD/../../install
      make -j
      make install
      cd ../..
    fi
    if [ ! -d "./libtool" ]; then
      wget http://ftp.gnu.org/gnu/libtool/libtool-2.4.4.tar.gz
      tar -xvf libtool-2.4.4.tar.gz
      rm libtool-2.4.4.tar.gz; cd libtool-2.4.4; mkdir build; cd build
      ../configure --prefix=$PWD/../../install
      make -j
      make install
      cd ../../../..
    fi
  fi

  if [ ! -d "./tpl/mpich/install" ]; then
    mkdir -p tpl && cd tpl
    export PATH=$PWD/autotools/install/bin:$PATH
    export LD_LIBRARY_PATH=$PWD/autotools/install/lib:$LD_LIBRARY_PATH
    if [ ! -d "./mpich" ]; then
      git clone --branch 3.2.x https://github.com/pmodels/mpich.git mpich
    fi
    cd mpich; ./autogen.sh; mkdir build; cd build
    ../configure --prefix=${PWD}/../install 
    make -j$(nproc); make install; cd ../../..
  fi
}

# #################################################
# Pre-requisites check
# #################################################
# Exit code 0: alls well
# Exit code 1: problems with getopt
# Exit code 2: problems with supported platforms

# check if getopt command is installed
type getopt > /dev/null
if [[ $? -ne 0 ]]; then
  echo "This script uses getopt to parse arguments; try installing the util-linux package";
  exit 1
fi

# os-release file describes the system
if [[ -e "/etc/os-release" ]]; then
  source /etc/os-release
else
  echo "This script depends on the /etc/os-release file"
  exit 2
fi

# The following function exits script if an unsupported distro is detected
supported_distro

# #################################################
# global variables
# #################################################
mpi_vendor=mpich
install_package=false
install_dependencies=false
with_rocm=/opt/rocm
with_mpi=tpl/${mpi_vendor}
with_fftw=tpl/fftw
openmpi_ucx=false
verbose_print=true
progress_report=true
detailed_timing=true

# #################################################
# Parameter parsing
# #################################################

# check if we have a modern version of getopt that can handle whitespace and long parameters
getopt -T
if [[ $? -eq 4 ]]; then
  GETOPT_PARSE=$(getopt --name "${0}" --longoptions help,install,dependencies,debug,with-rocm:,with-mpi:,with-cpublas:,gpu-aware-mpi:,verbose-print:,progress-report:,detailed-timing: --options hidg -- "$@")
else
  echo "Need a new version of getopt"
  exit 1
fi

if [[ $? -ne 0 ]]; then
  echo "getopt invocation failed; could not parse the command line";
  exit 1
fi

eval set -- "${GETOPT_PARSE}"

while true; do
  case "${1}" in
    -h|--help)
        display_help
        exit 0
        ;;
    -i|--install)
        install_package=true
        shift ;;
    -d|--dependencies)
        install_dependencies=true
        shift ;;
    --with-rocm)
        with_rocm=${2}
        shift 2 ;;
    --with-mpi)
        with_mpi=${2}
        shift 2 ;;
    --with-fftw)
        with_fftw=${2}
        shift 2 ;;
    --verbose-print)
        verbose_print=${2}
        shift 2 ;;
    --progress-report)
        progress_report=${2}
        shift 2 ;;
    --detailed-timing)
        detailed_timing=${2}
        shift 2 ;;
    --) shift ; break ;;
    *)  echo "Unexpected command line parameter received; aborting";
        exit 1
        ;;
  esac
done

# #################################################
# prep
# #################################################


# #################################################
# dependencies
# #################################################
if [[ "${install_dependencies}" == true ]]; then

  install_packages

fi

# We append customary rocm path; if user provides custom rocm path in ${path}, our
# hard-coded path has lesser priority
export ROCM_PATH=${with_rocm}
export PATH=${PATH}:${ROCM_PATH}/bin

pushd .
  # #################################################
  # MPI
  # #################################################
  if [[ "${with_mpi}" == tpl/${mpi_vendor} ]]; then

    openmpi_ucx=true
    if [[ "${mpi_vendor}" == mpich ]]; then
      install_mpich;
    else
      install_openmpi;
    fi
      
    with_mpi=$PWD/${with_mpi}/install

  fi

  # #################################################
  # FFTW
  # #################################################
  if [[ "${with_fftw}" == tpl/fftw ]]; then

    install_fftw
    with_fftw=$PWD/${with_fftw}

  fi

  # #################################################
  # configure & build
  # #################################################
  echo PWD: $PWD
  sed -i "/FFTW_ROOT=/c\FFTW_ROOT=${with_fftw}" src/cpu/${BUILD_SCRIPT}
  sed -i "/export MPI_HOME/c\export MPI_HOME=${with_mpi}" src/cpu/${BUILD_SCRIPT}
  sed -i "/export ROCM_PATH/c\export ROCM_PATH=${with_rocm}" src/cpu/${BUILD_SCRIPT}
  if [[ "${mpi_vendor}" == mpich ]]; then
    sed -i "s/lmpi_cxx/lmpicxx/g" src/cpu/${BUILD_SCRIPT}
  else
    sed -i "s/lmpicxx/lmpi_cxx/g" src/cpu/${BUILD_SCRIPT}
  fi
  export LD_LIBRARY_PATH=$PWD/tpl/${mpi_vendor}/install/lib:$LD_LIBRARY_PATH
  export PATH=$PWD/tpl/${mpi_vendor}/install/bin:$PATH
  export MPI_HOME=${with_mpi}
  export ROCM_PATH=${with_rocm}
  echo PATH:$PATH
  echo LD_LIBRARY_PATH:$LD_LIBRARY_PATH
  if [ ! -f "src/cpu/redwood/hacc_tpm" ]; then
    echo -e "${GREEN}HACC binary does not exist. Proceeding to build${NC}"
    cd src/cpu
    ./${BUILD_SCRIPT} 
  else
    echo -e "${GREEN}HACC binary already built. Delete src/cpu/redwood/hacc_tpm to rebuild${NC}"
  fi

  # #################################################
  # install
  # #################################################
  # installing through package manager, which makes uninstalling easy
  if [[ "${install_package}" == true ]]; then
    make package
    check_exit_code

    case "${ID}" in
      ubuntu)
        elevate_if_not_root dpkg -i hacc-*.deb
      ;;
      centos|rhel)
        elevate_if_not_root yum -y localinstall hacc-*.rpm
      ;;
      fedora)
        elevate_if_not_root dnf install hacc-*.rpm
      ;;
      sles)
        elevate_if_not_root zypper -n --no-gpg-checks install hacc-*.rpm
      ;;
    esac
  fi
popd
