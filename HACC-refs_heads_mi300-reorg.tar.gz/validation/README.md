#Script for validating the correctness of a full CORAL2 HACC run using the generated output files

## Usage:
* ./validation.sh <y.m000.pk.ini> <y.m000.pk.fin> <x.m000.pk.ini> <x.m000.pk.fin>
  * <**y**.m000.pk.**ini**>: (required) some metric taken at the begining of the simulation just after initiailization.
  * <**y**.m000.pk.**fin**>: (required) some metric taken again at the end of the simulation.
  * <**x**.m000.pk.**ini**>: (optional) another file with "accepted" values to compare with y.m000.pk.ini. If no file is provided on the command line then an .ini file will be used from an accepted ground truth CORAL2 run with np=320.
  * <**x**.m000.pk.**fin**>: (optional) another file with "accepted" values to compare with y.m000.pk.fin. If no file is provided on the command line then an .fin file will be used from an accepted ground truth CORAL2 run with np=320.

## Results:
* The script will validate the .ini file to make sure the initial domain constructed in the given HACC simulation matches that of the CORAL2 p2 problem.
  * Max relative error: |y.m000.pk.ini - x.m000.pk.ini| / x.m000.pk.ini
* The script also validates the .fin file by computing the max relative error at each datapoint. 
  * Max relative error: |y.m000.pk.fin - x.m000.pk.fin| / x.m000.pk.fin

## Solutions:
* A set of known solutions to compare with is provided in the "solutions" directory. Each directory also contains an indat file which shows the exact configuration which generated the output files.
