/*=========================================================================
                                                                                
Copyright (c) 2007, Los Alamos National Security, LLC

All rights reserved.

Copyright 2007. Los Alamos National Security, LLC. 
This software was produced under U.S. Government contract DE-AC52-06NA25396 
for Los Alamos National Laboratory (LANL), which is operated by 
Los Alamos National Security, LLC for the U.S. Department of Energy. 
The U.S. Government has rights to use, reproduce, and distribute this software. 
NEITHER THE GOVERNMENT NOR LOS ALAMOS NATIONAL SECURITY, LLC MAKES ANY WARRANTY,
EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  
If software is modified to produce derivative works, such modified software 
should be clearly marked, so as not to confuse it with the version available 
from LANL.
 
Additionally, redistribution and use in source and binary forms, with or 
without modification, are permitted provided that the following conditions 
are met:
-   Redistributions of source code must retain the above copyright notice, 
    this list of conditions and the following disclaimer. 
-   Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution. 
-   Neither the name of Los Alamos National Security, LLC, Los Alamos National
    Laboratory, LANL, the U.S. Government, nor the names of its contributors
    may be used to endorse or promote products derived from this software 
    without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY LOS ALAMOS NATIONAL SECURITY, LLC AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
ARE DISCLAIMED. IN NO EVENT SHALL LOS ALAMOS NATIONAL SECURITY, LLC OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
                                                                                
=========================================================================*/

#include <iostream>
#include <iomanip>

#include "Partition.h"
#include "GridExchange.h"
#include "gpu.h"

#include <cassert>
#include <cstdlib>

using namespace std;

/////////////////////////////////////////////////////////////////////////
//
// GridExchange will take a pointer to contiguous memory, the size of
// memory in each dimension, and the amount of dead grid information
// to be shared on the front and back of every dimension.  From this
// GridExchange can calculate what part of the contiguous memory must be
// packed to share with each of the neighbors, and what part of its own
// memory must be used to unpack similar information from each neighbor.
//
// This can be accomplished by recording for every neighbor the send
// origin and send size, the receive origin and receive size.
//
/////////////////////////////////////////////////////////////////////////

GridExchange::GridExchange(
			int* size,
			int ghost0,
			int ghost1)
{
  // Get the number of processors running this problem and rank
  numProc = Partition::getNumProc();
  myProc = Partition::getMyProc();

  // Get the number of processors in each dimension
  Partition::getDecompSize(layoutSize);

  // Get my position within the Cartesian topology
  Partition::getMyPosition(layoutPos);

  // Get neighbors of this processor including the wraparound
  Partition::getNeighbors(neighbor);

  // Store sizes for this exchange which depend on alive and dead grid zones
  dead0 = ghost0;
  dead1 = ghost1; 

  for (int dim = 0; dim < DIMENSION; dim++) {
    totalSize[dim] = size[dim];
    alive[dim] = size[dim] - dead0 - dead1;
  }

  // Initialize this exchanger with a given size to save the calculation
  // every time data is to be sent
  initialize();
  resurrectBuffers();
}

GridExchange::~GridExchange()
{
  dropBuffers();
}

void GridExchange::dropBuffers()
{
  CHECK(hipFree(recv.bufferD[0]));
  for (int r = 0; r < NUM_OF_NEIGHBORS; r++) recv.bufferD[r] = send.bufferD[r] = nullptr;
}

void GridExchange::resurrectBuffers()
{
  CHECK(hipMalloc(recv.bufferD,bufferSize));
  assert(recv.bufferD[0]);
  const int nr = NUM_OF_NEIGHBORS-1;
  for (int r = 0; r < nr; r++) recv.bufferD[r+1] = recv.bufferD[r]+recv.size[r][0];
  send.bufferD[0] = recv.bufferD[nr]+recv.size[nr][0];
  for (int r = 0; r < nr; r++) send.bufferD[r+1] = send.bufferD[r]+send.size[r][0];
}

/////////////////////////////////////////////////////////////////////////
//
// Calculate information needed for neighbor exchange of dead grids
// For each neighbor sent to their is an offset into the alive grid and
// a size of the region to be sent.  For each neighbor received from there
// is an offset into the dead grid and a size of the region where the
// data will be unpacked.
//
/////////////////////////////////////////////////////////////////////////

void GridExchange::initialize()
{
  /////////////////////////////////////////////////////////////////////////
  //
  // Send left and receive right face
  setSendOrigin(X0, 
                dead0, 
                dead0, 
                dead0);
  setRecvOrigin(X1, 
                dead0 + alive[0], 
                dead0, 
                dead0);
  setSendSize(X0, dead1, alive[1], alive[2]);
  setRecvSize(X1, dead1, alive[1], alive[2]);

  // Send right and receive left face
  setSendOrigin(X1,
                dead0 + alive[0] - dead0,
                dead0,
                dead0);
  setRecvOrigin(X0, 
                0, 
                dead0, 
                dead0);
  setSendSize(X1, dead0, alive[1], alive[2]);
  setRecvSize(X0, dead0, alive[1], alive[2]);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send bottom and receive top face
  setSendOrigin(Y0, 
                dead0, 
                dead0, 
                dead0);
  setRecvOrigin(Y1, 
                dead0, 
                dead0 + alive[1], 
                dead0);
  setSendSize(Y0, alive[0], dead1, alive[2]);
  setRecvSize(Y1, alive[0], dead1, alive[2]);

  // Send top and receive bottom face
  setSendOrigin(Y1,
                dead0,
                dead0 + alive[1] - dead0,
                dead0);
  setRecvOrigin(Y0, 
                dead0, 
                0, 
                dead0);
  setSendSize(Y1, alive[0], dead0, alive[2]);
  setRecvSize(Y0, alive[0], dead0, alive[2]);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send front and receive back face
  setSendOrigin(Z0, 
                dead0, 
                dead0, 
                dead0);
  setRecvOrigin(Z1, 
                dead0, 
                dead0, 
                dead0 + alive[2]);
  setSendSize(Z0, alive[0], alive[1], dead1);
  setRecvSize(Z1, alive[0], alive[1], dead1);

  // Send back and receive front face
  setSendOrigin(Z1,
                dead0,
                dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(Z0, 
                dead0, 
                dead0, 
                0);
  setSendSize(Z1, alive[0], alive[1], dead0);
  setRecvSize(Z0, alive[0], alive[1], dead0);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send left bottom edge and receive right top edge
  setSendOrigin(X0_Y0, 
                dead0, 
                dead0, 
                dead0);
  setRecvOrigin(X1_Y1,
                dead0 + alive[0],
                dead0 + alive[1],
                dead0);
  setSendSize(X0_Y0, dead1, dead1, alive[2]);
  setRecvSize(X1_Y1, dead1, dead1, alive[2]);

  // Send right top edge and receive left bottom edge
  setSendOrigin(X1_Y1,
                dead0 + alive[0] - dead0,
                dead0 + alive[1] - dead0,
                dead0);
  setRecvOrigin(X0_Y0, 
                0, 
                0, 
                dead0);
  setSendSize(X1_Y1, dead0, dead0, alive[2]);
  setRecvSize(X0_Y0, dead0, dead0, alive[2]);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send left top edge and receive right bottom edge
  setSendOrigin(X0_Y1, 
                dead0, 
                dead0 + alive[1] - dead0, 
                dead0);
  setRecvOrigin(X1_Y0, 
                dead0 + alive[0], 
                0,
                dead0);
  setSendSize(X0_Y1, dead1, dead0, alive[2]);
  setRecvSize(X1_Y0, dead1, dead0, alive[2]);

  // Send right bottom edge and receive left top edge
  setSendOrigin(X1_Y0,
                dead0 + alive[0] - dead0,
                dead0,
                dead0);
  setRecvOrigin(X0_Y1, 
                0, 
                dead0 + alive[1],
                dead0);
  setSendSize(X1_Y0, dead0, dead1, alive[2]);
  setRecvSize(X0_Y1, dead0, dead1, alive[2]);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send bottom front edge and receive top back edge
  setSendOrigin(Y0_Z0,
                dead0,
                dead0,
                dead0);
  setRecvOrigin(Y1_Z1,
                dead0,
                dead0 + alive[1],
                dead0 + alive[2]);
  setSendSize(Y0_Z0, alive[0], dead1, dead1);
  setRecvSize(Y1_Z1, alive[0], dead1, dead1);

  // Send top back edge and receive bottom front edge
  setSendOrigin(Y1_Z1,
                dead0,
                dead0 + alive[1] - dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(Y0_Z0,
                dead0,
                0,
                0);
  setSendSize(Y1_Z1, alive[0], dead0, dead0);
  setRecvSize(Y0_Z0, alive[0], dead0, dead0);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send bottom back edge and receive top front edge
  setSendOrigin(Y0_Z1,
                dead0,
                dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(Y1_Z0,
                dead0,
                dead0 + alive[1],
                0);
  setSendSize(Y0_Z1, alive[0], dead1, dead0);
  setRecvSize(Y1_Z0, alive[0], dead1, dead0);

  // Send top front edge and receive bottom back edge
  setSendOrigin(Y1_Z0,
                dead0,
                dead0 + alive[1] - dead0,
                dead0);
  setRecvOrigin(Y0_Z1,
                dead0,
                0,
                dead0 + alive[2]);
  setSendSize(Y1_Z0, alive[0], dead0, dead1);
  setRecvSize(Y0_Z1, alive[0], dead0, dead1);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send front left edge and receive back right edge
  setSendOrigin(Z0_X0,
                dead0,
                dead0,
                dead0);
  setRecvOrigin(Z1_X1,
                dead0 + alive[0],
                dead0,
                dead0 + alive[2]);
  setSendSize(Z0_X0, dead1, alive[1], dead1);
  setRecvSize(Z1_X1, dead1, alive[1], dead1);

  // Send back right edge and receive front left edge
  setSendOrigin(Z1_X1,
                dead0 + alive[0] - dead0,
                dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(Z0_X0,
                0,
                dead0,
                0);
  setSendSize(Z1_X1, dead0, alive[1], dead0);
  setRecvSize(Z0_X0, dead0, alive[1], dead0);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send front right edge and receive back left edge
  setSendOrigin(Z0_X1,
                dead0 + alive[0] - dead0,
                dead0,
                dead0);
  setRecvOrigin(Z1_X0,
                0,
                dead0,
                dead0 + alive[2]);
  setSendSize(Z0_X1, dead0, alive[1], dead1);
  setRecvSize(Z1_X0, dead0, alive[1], dead1);

  // Send back left edge and receive front right edge
  setSendOrigin(Z1_X0,
                dead0,
                dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(Z0_X1,
                dead0 + alive[0],
                dead0,
                0);
  setSendSize(Z1_X0, dead1, alive[1], dead0);
  setRecvSize(Z0_X1, dead1, alive[1], dead0);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send left bottom front corner and receive right top back corner
  setSendOrigin(X0_Y0_Z0,
                dead0,
                dead0,
                dead0);
  setRecvOrigin(X1_Y1_Z1,
                dead0 + alive[0],
                dead0 + alive[1],
                dead0 + alive[2]);
  setSendSize(X0_Y0_Z0, dead1, dead1, dead1);
  setRecvSize(X1_Y1_Z1, dead1, dead1, dead1);

  // Send right top back corner and receive left bottom front corner
  setSendOrigin(X1_Y1_Z1,
                dead0 + alive[0] - dead0,
                dead0 + alive[1] - dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(X0_Y0_Z0,
                0,
                0,
                0);
  setSendSize(X1_Y1_Z1, dead0, dead0, dead0);
  setRecvSize(X0_Y0_Z0, dead0, dead0, dead0);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send left bottom back corner and receive right top front corner
  setSendOrigin(X0_Y0_Z1,
                dead0,
                dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(X1_Y1_Z0,
                dead0 + alive[0],
                dead0 + alive[1],
                0);
  setSendSize(X0_Y0_Z1, dead1, dead1, dead0);
  setRecvSize(X1_Y1_Z0, dead1, dead1, dead0);

  // Send right top front corner and receive left bottom back corner
  setSendOrigin(X1_Y1_Z0,
                dead0 + alive[0] - dead0,
                dead0 + alive[1] - dead0,
                dead0);
  setRecvOrigin(X0_Y0_Z1,
                0,
                0,
                dead0 + alive[2]);
  setSendSize(X1_Y1_Z0, dead0, dead0, dead1);
  setRecvSize(X0_Y0_Z1, dead0, dead0, dead1);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send left top front corner and receive right bottom back corner
  setSendOrigin(X0_Y1_Z0,
                dead0,
                dead0 + alive[1] - dead0,
                dead0);
  setRecvOrigin(X1_Y0_Z1,
                dead0 + alive[0],
                0,
                dead0 + alive[2]);
  setSendSize(X0_Y1_Z0, dead1, dead0, dead1);
  setRecvSize(X1_Y0_Z1, dead1, dead0, dead1);

  // Send right bottom back corner and receive left top front corner
  setSendOrigin(X1_Y0_Z1,
                dead0 + alive[0] - dead0,
                dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(X0_Y1_Z0,
                0,
                dead0 + alive[1],
                0);
  setSendSize(X1_Y0_Z1, dead0, dead1, dead0);
  setRecvSize(X0_Y1_Z0, dead0, dead1, dead0);

  /////////////////////////////////////////////////////////////////////////
  //
  // Send left top back corner and receive right bottom front corner
  setSendOrigin(X0_Y1_Z1,
                dead0,
                dead0 + alive[1] - dead0,
                dead0 + alive[2] - dead0);
  setRecvOrigin(X1_Y0_Z0,
                dead0 + alive[0],
                0,
                0);
  setSendSize(X0_Y1_Z1, dead1, dead0, dead0);
  setRecvSize(X1_Y0_Z0, dead1, dead0, dead0);

  // Send right bottom front corner and receive left top back corner
  setSendOrigin(X1_Y0_Z0,
              dead0 + alive[0] - dead0,
              dead0,
              dead0);
  setRecvOrigin(X0_Y1_Z1,
              0,
              dead0 + alive[1],
              dead0 + alive[2]);
  setSendSize(X1_Y0_Z0, dead0, dead1, dead1);
  setRecvSize(X0_Y1_Z1, dead0, dead1, dead1);

  bufferSize = 0;
  recvBlocks = 0;
  sendBlocks = 0;
  for (int r = 0; r < NUM_OF_NEIGHBORS; r++) {
    const int recvCount = recv.size[r][0];
    const int sendCount = send.size[r][0];
    recvBlocks = std::max(recvBlocks,recvCount);
    sendBlocks = std::max(sendBlocks,sendCount);
    bufferSize += recvCount+sendCount;
  }
  recvBlocks = (recvBlocks+gpuBlockSize-1)/gpuBlockSize;
  sendBlocks = (sendBlocks+gpuBlockSize-1)/gpuBlockSize;
  bufferSize *= sizeof(GRID_T);
}

/////////////////////////////////////////////////////////////////////////////
//
// Short cuts for setting send/receive origins and sizes to make the
// code more readable
//
/////////////////////////////////////////////////////////////////////////////

void GridExchange::setSendOrigin(int whichNeighbor, int x, int y, int z)
{
  send.origin[whichNeighbor][0] = x;
  send.origin[whichNeighbor][1] = y;
  send.origin[whichNeighbor][2] = z;
}

void GridExchange::setRecvOrigin(int whichNeighbor, int x, int y, int z)
{
  recv.origin[whichNeighbor][0] = x;
  recv.origin[whichNeighbor][1] = y;
  recv.origin[whichNeighbor][2] = z;
}

void GridExchange::setSendSize(int whichNeighbor, int x, int y, int z)
{
  send.size[whichNeighbor][0] = x*y*z;
  send.size[whichNeighbor][1] = y*z;
  send.size[whichNeighbor][2] = z;
}

void GridExchange::setRecvSize(int whichNeighbor, int x, int y, int z)
{
  recv.size[whichNeighbor][0] = x*y*z;
  recv.size[whichNeighbor][1] = y*z;
  recv.size[whichNeighbor][2] = z;
}

/////////////////////////////////////////////////////////////////////////////
//
// Exchange the appropriate grid regions with neighbors
// Use the Cartesian communicator for neighbor exchange
//
/////////////////////////////////////////////////////////////////////////////


__launch_bounds__(gpuBlockSize) __global__
static void copyToSend(const GridCopyArgs send, const int planeSize, const int rowSize, const GRID_T *const data)
{
  const int ijk = threadIdx.x+blockIdx.x*blockDim.x;
  for (int r = 0; r < NUM_OF_NEIGHBORS; r++) {
    const int nijk = send.size[r][0];
    if (ijk < nijk) {
      const int njk = send.size[r][1];
      const int nk = send.size[r][2];
      const int di = send.origin[r][0];
      const int dj = send.origin[r][1];
      const int dk = send.origin[r][2];
      GRID_T *const buf = send.bufferD[r];
      const int i = ijk/njk;
      const int jnk = ijk-i*njk;
      const int j = jnk/nk;
      const int k = jnk-j*nk;
      const int id = (i+di)*planeSize+(j+dj)*rowSize+k+dk;
      buf[ijk] = data[id];
    }
  }
}

__launch_bounds__(gpuBlockSize) __global__
static void copyFromRecv(const GridCopyArgs recv, const int planeSize, const int rowSize, GRID_T *const data)
{
  const int ijk = threadIdx.x+blockIdx.x*blockDim.x;
  for (int r = 0; r < NUM_OF_NEIGHBORS; r++) {
    const int nijk = recv.size[r][0];
    if (ijk < nijk) {
      const int njk = recv.size[r][1];
      const int nk = recv.size[r][2];
      const int di = recv.origin[r][0];
      const int dj = recv.origin[r][1];
      const int dk = recv.origin[r][2];
      const GRID_T *const buf = recv.bufferD[r];
      const int i = ijk/njk;
      const int jnk = ijk-i*njk;
      const int j = jnk/nk;
      const int k = jnk-j*nk;
      const int id = (i+di)*planeSize+(j+dj)*rowSize+k+dk;
      data[id] = buf[ijk];
    }
  }
}

void GridExchange::exchangeGrid(GRID_T *const dataD)
{
  for (int r = 0; r < NUM_OF_NEIGHBORS; r += 2) {
    MPI_Irecv(recv.bufferD[r],recv.size[r][0],MPI_FLOAT,neighbor[r],r+1,Partition::getComm(),recvReq+r);
    MPI_Irecv(recv.bufferD[r+1],recv.size[r+1][0],MPI_FLOAT,neighbor[r+1],r+2,Partition::getComm(),recvReq+r+1);
  }
  const int planeSize = totalSize[1]*totalSize[2];
  const int rowSize = totalSize[2];
  copyToSend<<<sendBlocks,gpuBlockSize>>>(send,planeSize,rowSize,dataD);
  CHECK(hipGetLastError());
  CHECK(hipDeviceSynchronize());
  for (int r = 0; r < NUM_OF_NEIGHBORS; r += 2) {
    MPI_Isend(send.bufferD[r],send.size[r][0],MPI_FLOAT,neighbor[r],r+2,Partition::getComm(),sendReq+r);
    MPI_Isend(send.bufferD[r+1],send.size[r+1][0],MPI_FLOAT,neighbor[r+1],r+1,Partition::getComm(),sendReq+r+1);
  }
  MPI_Waitall(NUM_OF_NEIGHBORS,recvReq,MPI_STATUSES_IGNORE);
  copyFromRecv<<<recvBlocks,gpuBlockSize>>>(recv,planeSize,rowSize,dataD);
  CHECK(hipGetLastError());
  MPI_Waitall(NUM_OF_NEIGHBORS,sendReq,MPI_STATUSES_IGNORE);
}


