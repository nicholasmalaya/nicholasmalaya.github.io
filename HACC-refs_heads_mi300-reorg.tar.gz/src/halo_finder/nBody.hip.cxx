#include "nBody.h"
#include "gpu.h"

#include <cfloat>

static constexpr int ntLimit = 512;

__device__
static void nBodyF(float &ax, float &ay, float &az, __shared__ float *const __restrict__ x, __shared__ float *const __restrict__ y, __shared__ float *const __restrict__ z, const float *const xx, const float *const yy, const float *const zz, const float xxh, const float yyh, const float zzh, const float fsrrMax2, const float rsm2, const int offset, const int count, const bool mask)
{
  static constexpr float ma0 = 0.269327f, ma1 = -0.0750978f, ma2 = 0.0114808f, ma3 = -0.00109313f, ma4 = 0.0000605491f, ma5 = -0.00000147177f;
  const int g = threadIdx.x;
  __syncthreads();
  if (g < count) {
    const int k = offset+g;
    x[g] = xx[k];
    y[g] = yy[k];
    z[g] = zz[k];
  } else if (g == count) {
    x[g] = y[g] = z[g] = -FLT_MAX;
  }
  __syncthreads();

  if (mask) for (int k = 0; k < count; k += 2) {

    const float2 xk{x[k],x[k+1]};
    const float2 yk{y[k],y[k+1]};
    const float2 zk{z[k],z[k+1]};

    const float2 dxc = xk-xxh;
    float2 r2 = float2(dxc).operator*=(dxc);
    const float2 dyc = yk-yyh;
    r2.operator+=(float2(dyc).operator*=(dyc));
    const float2 dzc = zk-zzh;
    r2.operator+=(float2(dzc).operator*=(dzc));

    const bool left = ((r2.x < fsrrMax2) && (r2.x > 0.0f));
    const bool right = ((r2.y < fsrrMax2) && (r2.y > 0.0f));
    const bool either = (left || right);
    const bool both = (left && right);

    if (either) {

      const float2 s0 = r2+rsm2;
      const float2 s1 = float2(s0).operator*=(float2(s0).operator*=(s0));
      const float2 s3 = float2(ma0)+float2(r2).operator*=(float2(ma1)+float2(r2).operator*=(float2(ma2)+float2(r2).operator*=(float2(ma3)+float2(r2).operator*=(float2(ma4)+float2(r2).operator*=(float2(ma5))))));

      const float denom = left ? s1.x : s1.y;
      const float series = left ? s3.x : s3.y;
      const float f = rsqrt(denom)-series;
      ax += f*(left ? dxc.x : dxc.y);
      ay += f*(left ? dyc.x : dyc.y);
      az += f*(left ? dzc.x : dzc.y);

      if (both) {
        const float f = rsqrt(s1.y)-s3.y;
        ax += f*dxc.y;
        ay += f*dyc.y;
        az += f*dzc.y;
      }
    }
  }
}

__global__ __launch_bounds__(warpSize)
static void pruneG(const TreeNode *const tree, const int *const leaves, int *const nss, int *const ss, const float fsrrMax)
{
  __shared__ int nq,nr,ns,q[warpSize],r[warpSize];

  const int tl = leaves[blockIdx.x];
  int *const s = ss+tree[tl].offset;

  if (threadIdx.x == 0) {
    int lq = 0;
    int child = tl;
    while (child) {
      const int parent = tree[child].parent;
      const int tpcl = tree[parent].cl;
      if (tpcl == child) {
        const int tpcr = tree[parent].cr;
        if (tpcr > 0) q[lq++] = tpcr;
      } else if (tpcl > 0) q[lq++] = tpcl;
      child = parent;
    }
    nq = lq;
    nr = 0;
    ns = 1;
    s[0] = tl; // interact with self
  }
  __threadfence_block();

  while (nq) {

    if (threadIdx.x < nq) {

      const int tln = q[threadIdx.x];
      const int tlncl = tree[tln].cl;
      const int tlncr = tree[tln].cr;

      if (tlncr == 0 && tlncl == 0) {

        s[atomicAdd(&ns,1)] = tln;

      } else {

        if (tlncl > 0 && tree[tlncl].count > 0) {
          bool close = true;
          for (int j = 0; j < DIMENSION; j++) {
            float dist = 0;
            if (tree[tl].xmax[j] < tree[tlncl].xmin[j]) {
              dist = tree[tlncl].xmin[j]-tree[tl].xmax[j];
            } else if (tree[tl].xmin[j] > tree[tlncl].xmax[j]) {
              dist = tree[tl].xmin[j]-tree[tlncl].xmax[j];
            }
            if (dist > fsrrMax) {
              close = false;
              break;
            }
          }
          if (close) r[atomicAdd(&nr,1)] = tlncl;
        }

        if (tlncr > 0 && tree[tlncr].count > 0) {
          bool close = true;
          for (int j = 0; j < DIMENSION; j++) {
            float dist = 0;
            if (tree[tl].xmax[j] < tree[tlncr].xmin[j]) {
              dist = tree[tlncr].xmin[j]-tree[tl].xmax[j];
            } else if (tree[tl].xmin[j] > tree[tlncr].xmax[j]) {
              dist = tree[tl].xmin[j]-tree[tlncr].xmax[j];
            }
            if (dist > fsrrMax) {
              close = false;
              break;
            }
          }
          if (close) r[atomicAdd(&nr,1)] = tlncr;
        }
      }
    }
    __threadfence_block();

    if (threadIdx.x < nr) q[threadIdx.x] = r[threadIdx.x];
    if (threadIdx.x == 0) nq = nr;

    __threadfence_block();

    if (threadIdx.x == 0) nr = 0;

    __threadfence_block();
  }
  if (threadIdx.x == 0) nss[blockIdx.x] = ns;
}

__global__ __launch_bounds__(ntLimit)
static void nBodyG(const TreeNode *const tree, const int *const leaves, const int *const nss, const int *const ss, const float *const xx, const float *const yy, const float *const zz, float *const __restrict vx, float *const __restrict vy, float *const __restrict vz, const float fCoeff, const float fsrrMax, const float rsm2)
{
  __shared__ float x[ntLimit],y[ntLimit],z[ntLimit];

  const int tl = leaves[blockIdx.x];
  const int ns = nss[blockIdx.x];
  const int *const s = ss+tree[tl].offset;

  const bool mask = (threadIdx.x < tree[tl].count);
  const int h = tree[tl].offset+threadIdx.x;
  const float xxh = (mask ? xx[h] : 0.0f);
  const float yyh = (mask ? yy[h] : 0.0f);
  const float zzh = (mask ? zz[h] : 0.0f);
  const float fsrrMax2 = fsrrMax*fsrrMax;
  float ax = 0;
  float ay = 0;
  float az = 0;
  for (int i = 0; i < ns; i++) {
    const TreeNode &node = tree[s[i]];
    nBodyF(ax,ay,az,x,y,z,xx,yy,zz,xxh,yyh,zzh,fsrrMax2,rsm2,node.offset,node.count,mask);
  }
  if (mask) {
    vx[h] += ax*fCoeff;
    vy[h] += ay*fCoeff;
    vz[h] += az*fCoeff;
  }
}

void nBody(Device &gpu, const float fCoeff, const float fsrrMax, const float rsm2)
{
  assert(gpu.ppn <= ntLimit);
  pruneG<<<gpu.statsH->nLeaves,warpSize>>>(gpu.treeD,gpu.leavesD,gpu.njs,gpu.swap,fsrrMax);
  nBodyG<<<gpu.statsH->nLeaves,gpu.ppn>>>(gpu.treeD,gpu.leavesD,gpu.njs,gpu.swap,gpu.xx,gpu.yy,gpu.zz,gpu.vx,gpu.vy,gpu.vz,fCoeff,fsrrMax,rsm2);
  CHECK(hipGetLastError());
}
