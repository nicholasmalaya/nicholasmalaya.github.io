#include "RCBForceTree.h"
#include "gpu.h"

#include <algorithm>
#include <cfloat>
#include <climits>
#include <utility>

static constexpr int maxWarps = gpuMaxThreads/warpSize;

static __device__ void atomicMaxNoRet(float *const g, float x)
{
  atomicMax(reinterpret_cast<int*>(g),*reinterpret_cast<int*>(&x));
}

static __device__ void atomicMinNoRet(float *const g, float x)
{
  atomicMin(reinterpret_cast<int*>(g),*reinterpret_cast<int*>(&x));
}

__launch_bounds__(gpuMaxThreads) __global__
static void cmD(TreeNode *const tree, const float *const xx, const float *const yy, const float *const zz)
{
  __shared__ double sx[maxWarps],sy[maxWarps],sz[maxWarps];
  __shared__ float sxMax[maxWarps],sxMin[maxWarps],syMax[maxWarps],syMin[maxWarps],szMax[maxWarps],szMin[maxWarps];

  TreeNode &node(tree[blockIdx.y]);

  const int thread = threadIdx.x;
  const int iBegin = node.offset+blockIdx.x*blockDim.x+thread;
  const int iEnd = node.offset+node.count;
  const int di = gridDim.x*blockDim.x;

  double x = 0;
  double y = 0;
  double z = 0;

  float xMax = 0;
  float xMin = FLT_MAX;
  float yMax = 0;
  float yMin = FLT_MAX;
  float zMax = 0;
  float zMin = FLT_MAX;

  for (int i = iBegin; i < iEnd; i += di) {

    const float xxi = xx[i];
    const float yyi = yy[i];
    const float zzi = zz[i];

    x += xxi;
    y += yyi;
    z += zzi;

    xMax = fmax(xMax,xxi);
    xMin = fmin(xMin,xxi);
    yMax = fmax(yMax,yyi);
    yMin = fmin(yMin,yyi);
    zMax = fmax(zMax,zzi);
    zMin = fmin(zMin,zzi);
  }

  // Warp reductions

  for (int i = 1; i < warpSize; i += i) {
    x += __shfl_down(x,i);
    y += __shfl_down(y,i);
    z += __shfl_down(z,i);
    xMax = fmax(xMax,__shfl_down(xMax,i));
    xMin = fmin(xMin,__shfl_down(xMin,i));
    yMax = fmax(yMax,__shfl_down(yMax,i));
    yMin = fmin(yMin,__shfl_down(yMin,i));
    zMax = fmax(zMax,__shfl_down(zMax,i));
    zMin = fmin(zMin,__shfl_down(zMin,i));
  }

  // Workgroup reductions


  if (blockDim.x > warpSize) {

    const int nWarps = blockDim.x/warpSize;
    const int warp = thread/warpSize;
    if (thread%warpSize == 0) {
      sx[warp] = x;
      sy[warp] = y;
      sz[warp] = z;
      sxMax[warp] = xMax;
      syMax[warp] = yMax;
      szMax[warp] = zMax;
      sxMin[warp] = xMin;
      syMin[warp] = yMin;
      szMin[warp] = zMin;
    }
    __syncthreads();

    if (warp == 0) {
      x = y = z = 0;
      xMax = yMax = zMax = 0;
      xMin = yMin = zMin = FLT_MAX;
      if (thread < nWarps) {
        x = sx[thread];
        y = sy[thread];
        z = sz[thread];
        xMax = sxMax[thread];
        yMax = syMax[thread];
        zMax = szMax[thread];
        xMin = sxMin[thread];
        yMin = syMin[thread];
        zMin = szMin[thread];
      }
      for (int i = 1; i < maxWarps; i += i) {
        x += __shfl_down(x,i);
        y += __shfl_down(y,i);
        z += __shfl_down(z,i);
        xMax = fmax(xMax,__shfl_down(xMax,i));
        xMin = fmin(xMin,__shfl_down(xMin,i));
        yMax = fmax(yMax,__shfl_down(yMax,i));
        yMin = fmin(yMin,__shfl_down(yMin,i));
        zMax = fmax(zMax,__shfl_down(zMax,i));
        zMin = fmin(zMin,__shfl_down(zMin,i));
      }
    }
  }

  // Per-workgroup update

  if (thread == 0) {
    const double divM = 1.0/double(node.count);
    x *= divM;
    y *= divM;
    z *= divM;
    if (gridDim.x == 1) {
      node.xmin[0] = xMin;
      node.xmin[1] = yMin;
      node.xmin[2] = zMin;
      node.xmax[0] = xMax;
      node.xmax[1] = yMax;
      node.xmax[2] = zMax;
      node.xc[0] = x;
      node.xc[1] = y;
      node.xc[2] = z;
    } else {
      atomicMinNoRet(node.xmin,xMin);
      atomicMinNoRet(node.xmin+1,yMin);
      atomicMinNoRet(node.xmin+2,zMin);
      atomicMaxNoRet(node.xmax,xMax);
      atomicMaxNoRet(node.xmax+1,yMax);
      atomicMaxNoRet(node.xmax+2,zMax);
      atomicAdd(node.xc,x);
      atomicAdd(node.xc+1,y);
      atomicAdd(node.xc+2,z);
    }
  }
}

void RCBForceTree::centersOfMassD(const int iLo, const int iHi)
{
  const int m = iHi-iLo;
  const int nby = m;
  const int nodeThreads = (particleCount+m-1)/m;
  const int nt = warpSize*std::min((nodeThreads+warpSize-1)/warpSize,maxWarps); // divisible by warpSize
  const int nbx = (nodeThreads+nt-1)/nt;
  hipLaunchKernelGGL(cmD,dim3(nbx,nby),nt,0,0,gpu.treeD+iLo,gpu.xx,gpu.yy,gpu.zz);
  CHECK(hipGetLastError());
}

__launch_bounds__(gpuMaxThreads) __global__
static void countD(const int nDirect, TreeNode *const tree, const float *const xx, const float *const yy, const float *const zz, int *const nls, char *const more)
{
  __shared__ int nl;

  const int m = blockIdx.y;
  TreeNode &node(tree[m]);
  if (node.count <= nDirect) return;

  if (threadIdx.x == 0) nl = 0;
  __syncthreads();

  const float dx = node.xmax[0]-node.xmin[0];
  const float dy = node.xmax[1]-node.xmin[1];
  const float dz = node.xmax[2]-node.xmin[2];
  const float *x = nullptr;
  float split = 0;
  if ((dx > dy) && (dx > dz)) {
    x = xx;
    split = node.xc[0];
  } else if (dy > dz) {
    x = yy;
    split = node.xc[1];
  } else {
    x = zz;
    split = node.xc[2];
  }
  const int iLo = node.offset+blockIdx.x*blockDim.x+threadIdx.x;
  const int iHi = node.offset+node.count;
  const int di = gridDim.x*blockDim.x;
  int n = 0;
  for (int i = iLo; i < iHi; i += di) {
    const char less = (x[i] < split);
    more[i] = !less;
    n += less;
  }

  for (int i = 1; i < warpSize; i += i) n += __shfl_down(n,i);
  if (threadIdx.x%warpSize == 0) atomicAdd(&nl,n);
  __syncthreads();

  if (threadIdx.x == 0) {
    atomicAdd(nls+m,nl);
  }
}

__device__
static void init(TreeNode *const node, const int count, const int offset, const int parent)
{ 
  node->count = count;
  node->offset = offset;
  node->parent = parent;
  node->cl = node->cr = 0;
  node->xmin[0] = node->xmin[1] = node->xmin[2] = FLT_MAX;
  node->xmax[0] = node->xmax[1] = node->xmax[2] = -FLT_MAX;
  node->xc[0] = node->xc[1] = node->xc[2] = 0.0f;
}

__launch_bounds__(gpuMaxThreads) __global__
void growG(const int mLo, const int mHi, const int nDirect, TreeNode *const tree, int *const nNodes, const int *const nls, TreeStats *const stats, int *const leaves, const float xMax, const float xMin, const float yMax, const float yMin, const float zMax, const float zMin)
{
  __shared__ int ag,pg;
  __shared__ int as[maxWarps],lps[maxWarps],mps[maxWarps],nzls[maxWarps],ps[maxWarps],zls[maxWarps];

  const int thread = threadIdx.x;
  const int warp = thread/warpSize;
  const int warpThread = thread%warpSize;

  if (thread == 0) ag = pg = 0;
  if (thread < maxWarps) as[thread] = lps[thread] = mps[thread] = nzls[thread] = ps[thread] = zls[thread] = 0;
  __syncthreads();

  const int m = mLo+thread+blockIdx.x*blockDim.x;
  const bool parent = ((m < mHi) && (tree[m].count > nDirect));
  const bool leaf = ((m < mHi) && (tree[m].count <= nDirect));
  const bool nzLeaf = (leaf && (tree[m].count > 0));
  const bool zLeaf = (leaf && !nzLeaf);
  const bool active = (leaf && (((tree[m].xmax[0] < xMax) && (tree[m].xmax[0] > xMin)) || ((tree[m].xmin[0] < xMax) && (tree[m].xmin[0] > xMin))) &&
          (((tree[m].xmax[1] < yMax) && (tree[m].xmax[1] > yMin)) || ((tree[m].xmin[1] < yMax) && (tree[m].xmin[1] > yMin))) &&
          (((tree[m].xmax[2] < zMax) && (tree[m].xmax[2] > zMin)) || ((tree[m].xmin[2] < zMax) && (tree[m].xmin[2] > zMin))));

  int at = active ? 1 : 0;
  int lpt = 0, mpt = 0, nzlt = 0;
  if (nzLeaf) {
    const int count = tree[m].count;
    lpt = count;
    mpt = count;
    nzlt = 1;
  }
  int pt = parent ? 2 : 0;
  int zlt = zLeaf ? 1 : 0;

  for (int i = 1; i < warpSize; i += i) {
    const int ai = __shfl_up(at,i);
    const int lpi = __shfl_up(lpt,i);
    const int mpi = __shfl_up(mpt,i);
    const int nzli = __shfl_up(nzlt,i);
    const int pi = __shfl_up(pt,i);
    const int zli = __shfl_up(zlt,i);
    if (warpThread >= i) {
      at += ai;
      lpt += lpi;
      mpt = (mpi > mpt) ? mpi : mpt;
      nzlt += nzli;
      pt += pi;
      zlt += zli;
    }
  }
  if (warpThread == warpSize-1) {
    as[warp] = at;
    lps[warp] = lpt;
    mps[warp] = mpt;
    nzls[warp] = nzlt;
    zls[warp] = zlt;
    ps[warp] = pt;
  }
  at--;
  pt -= 2;
  __syncthreads();

  if (blockDim.x < 6*warpSize) abort();

  if (warp == 0) {
    int aw = (warpThread < maxWarps) ? as[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) {
      const int ai = __shfl_up(aw,i);
      if (warpThread >= i) aw += ai;
    }
    if (warpThread < maxWarps) as[warpThread] = aw;
    if ((warpThread == maxWarps-1) && aw) ag = atomicAdd(&(stats->nLeaves),aw);
  } else if (warp == 1) {
    int pw = (warpThread < maxWarps) ? ps[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) {
      const int pi = __shfl_up(pw,i);
      if (warpThread >= i) pw += pi;
    }
    if (warpThread < maxWarps) ps[warpThread] = pw;
    if ((warpThread == maxWarps-1) && pw) pg = atomicAdd(nNodes,pw);
  } else if (warp == 2) {
    int lpw = (warpThread < maxWarps) ? lps[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) lpw += __shfl_down(lpw,i);
    if ((warpThread == 0) && lpw) atomicAdd(&(stats->leafParts),lpw);
  } else if (warp == 3) {
    int mpw = (warpThread < maxWarps) ? mps[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) {
      const int mpi = __shfl_down(mpw,i);
      mpw = (mpi > mpw) ? mpi : mpw;
    }
    if ((warpThread == 0) && mpw) atomicMax(&(stats->maxPPN),mpw);
  } else if (warp == 4) {
    int nzlw = (warpThread < maxWarps) ? nzls[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) nzlw += __shfl_down(nzlw,i);
    if ((warpThread == 0) && nzlw) atomicAdd(&(stats->nonzeroLeafNodes),nzlw);
  } else if (warp == 5) {
    int zlw = (warpThread < maxWarps) ? zls[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) zlw += __shfl_down(zlw,i);
    if ((warpThread == 0) && zlw) atomicAdd(&(stats->zeroLeafNodes),zlw);
  }
  __syncthreads();

  if (parent) {
    TreeNode &node = tree[m];
    const int nlm = nls[m];
    pt += pg;
    if (warp > 0) pt += ps[warp-1];
    node.cl = pt;
    node.cr = pt+1;
    init(tree+node.cl,nlm,node.offset,m);
    init(tree+node.cr,node.count-nlm,node.offset+nlm,m);
  }
  if (active) {
    at += ag;
    if (warp > 0) at += as[warp-1];
    leaves[at] = m;
  }
}

__launch_bounds__(gpuMaxThreads) __global__
static void pairD(const int nDirect, const TreeNode *const tree, const int *const nls, const char *const more, int *const njs, int *const nks, int *const __restrict swap)
{ 
  __shared__ int jg,js[maxWarps],kg,ks[maxWarps];

  const int m = blockIdx.y;
  const TreeNode &node = tree[m];
  if (node.count <= nDirect) return;

  const int nlm = nls[m];
  if (nlm > blockDim.x*gridDim.x) abort(); // require at least one thread per pair

  const int thread = threadIdx.x;
  if (thread == 0) jg = kg = 0;
  if (thread < maxWarps) js[thread] = ks[thread] = 0;
  __syncthreads();

  const int jHi = node.offset+nlm;
  const int kHi = node.offset+node.count;

  const int j = node.offset+thread+blockIdx.x*blockDim.x;
  const int k = j+nlm;

  const bool jOn = ((j < jHi) && more[j]);
  const bool kOn = ((k < kHi) && !more[k]);

  int jt = jOn;
  int kt = kOn;

  const int warp = thread/warpSize;
  const int warpThread = thread%warpSize;

  for (int i = 1; i < warpSize; i += i) {
    const int ji = __shfl_up(jt,i);
    const int ki = __shfl_up(kt,i);
    if (warpThread >= i) {
      jt += ji;
      kt += ki;
    }
  }
  if (warpThread == warpSize-1) {
    js[warp] = jt;
    ks[warp] = kt;
  }
  jt--;
  kt--;
  __syncthreads();

  if (blockDim.x < 2*warpSize) abort();

  if (warp == 0) {
    int jw = (warpThread < maxWarps) ? js[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) {
      const int ji = __shfl_up(jw,i);
      if (warpThread >= i) jw += ji;
    }
    if (warpThread < maxWarps) js[warpThread] = jw;
    if ((warpThread == maxWarps-1) && jw) jg = atomicAdd(njs+m,jw);
  } else if (warp == 1) {
    int kw = (warpThread < maxWarps) ? ks[warpThread] : 0;
    for (int i = 1; i < maxWarps; i += i) {
      const int ki = __shfl_up(kw,i);
      if (warpThread >= i) kw += ki;
    }
    if (warpThread < maxWarps) ks[warpThread] = kw;
    if ((warpThread == maxWarps-1) && kw) kg = atomicAdd(nks+m,kw);
  }
  __syncthreads();

  if (jOn) {
    jt += node.offset+jg;
    if (warp > 0) jt += js[warp-1];
    swap[jt] = j;
  }
  if (kOn) {
    kt += node.offset+nlm+kg;
    if (warp > 0) kt += ks[warp-1];
    swap[kt] = k;
  }
}

__launch_bounds__(warpSize) __global__
static void partG(const int nDirect, const TreeNode *const tree, const int *const nls, const int *const njs, const int *const swap, float *const __restrict xx, float *const __restrict yy, float *const __restrict zz, float *const __restrict vx, float *const __restrict vy, float *const __restrict vz)
{
  const int m = blockIdx.y;
  const TreeNode &node(tree[m]);
  if (node.count <= nDirect) return;

  const int offset = node.offset;
  const int nlm = nls[m];
  const int iLo = offset+blockIdx.x*blockDim.x+threadIdx.x;
  const int iHi = offset+njs[m];
  const int di = gridDim.x*blockDim.x;
  for (int i = iLo; i < iHi; i += di) {
    const int j = swap[i];
    const int k = swap[i+nlm];

    const float xxk = xx[k];
    const float yyk = yy[k];
    const float zzk = zz[k];
    const float vxk = vx[k];
    const float vyk = vy[k];
    const float vzk = vz[k];

    xx[k] = xx[j];
    yy[k] = yy[j];
    zz[k] = zz[j];
    vx[k] = vx[j];
    vy[k] = vy[j];
    vz[k] = vz[j];

    xx[j] = xxk;
    yy[j] = yyk;
    zz[j] = zzk;
    vx[j] = vxk;
    vy[j] = vyk;
    vz[j] = vzk;
  }
}

void RCBForceTree::partitionsD(const int iLo, const int iHi)
{
  const int m = iHi-iLo;

  const int nodeThreads = (particleCount+m-1)/m;
  const int nby = m;
  {
    const int nt = warpSize*std::min((nodeThreads+warpSize-1)/warpSize,maxWarps); // divisible by warpSize
    const int nbx = (nodeThreads+nt-1)/nt;
    hipLaunchKernelGGL(countD,dim3(nbx,nby),nt,0,0,nDirect,gpu.treeD+iLo,gpu.xx,gpu.yy,gpu.zz,gpu.nlD+iLo,gpu.more);
    CHECK(hipGetLastError());
  }
  {
    const int nt = warpSize*std::max(6,std::min((m+warpSize-1)/warpSize,maxWarps)); // divisible by warpSize;
    const int nb = (m+nt-1)/nt;
    growG<<<nb,nt>>>(iLo,iHi,nDirect,gpu.treeD,gpu.nNodesD,gpu.nlD,gpu.statsD,gpu.leavesD,maxForceRange[0],minForceRange[0],maxForceRange[1],minForceRange[1],maxForceRange[2],minForceRange[2]);
  }
  {
    const int nt = warpSize*std::min((nodeThreads+warpSize-1)/warpSize,maxWarps); // divisible by warpSize
    const int nbx = (nodeThreads+nt-1)/nt;
    pairD<<<dim3(nbx,nby),nt>>>(nDirect,gpu.treeD+iLo,gpu.nlD+iLo,gpu.more,gpu.njs+iLo,gpu.nks+iLo,gpu.swap);
    CHECK(hipGetLastError());
  }
  hipEvent_t nlCopy;
  CHECK(hipEventCreate(&nlCopy));
  CHECK(hipEventRecord(nlCopy,0));
  {
    const int nbx = (nodeThreads+warpSize-1)/warpSize;
    const int nt = warpSize;
    partG<<<dim3(nbx,nby),nt>>>(nDirect,gpu.treeD+iLo,gpu.nlD+iLo,gpu.njs+iLo,gpu.swap,gpu.xx,gpu.yy,gpu.zz,gpu.vx,gpu.vy,gpu.vz);
    CHECK(hipGetLastError());
  }
  CHECK(hipEventSynchronize(nlCopy));
  *gpu.nNodes = *gpu.nNodesD;
  CHECK(hipEventDestroy(nlCopy));
}

