/*=========================================================================
                                                                                
Copyright (c) 2007, Los Alamos National Security, LLC

All rights reserved.

Copyright 2007. Los Alamos National Security, LLC. 
This software was produced under U.S. Government contract DE-AC52-06NA25396 
for Los Alamos National Laboratory (LANL), which is operated by 
Los Alamos National Security, LLC for the U.S. Department of Energy. 
The U.S. Government has rights to use, reproduce, and distribute this software. 
NEITHER THE GOVERNMENT NOR LOS ALAMOS NATIONAL SECURITY, LLC MAKES ANY WARRANTY,
EXPRESS OR IMPLIED, OR ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  
If software is modified to produce derivative works, such modified software 
should be clearly marked, so as not to confuse it with the version available 
from LANL.
 
Additionally, redistribution and use in source and binary forms, with or 
without modification, are permitted provided that the following conditions 
are met:
-   Redistributions of source code must retain the above copyright notice, 
    this list of conditions and the following disclaimer. 
-   Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution. 
-   Neither the name of Los Alamos National Security, LLC, Los Alamos National
    Laboratory, LANL, the U.S. Government, nor the names of its contributors
    may be used to endorse or promote products derived from this software 
    without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY LOS ALAMOS NATIONAL SECURITY, LLC AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
ARE DISCLAIMED. IN NO EVENT SHALL LOS ALAMOS NATIONAL SECURITY, LLC OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
                                                                                
=========================================================================*/

/*=========================================================================

Copyright (c) 2011-2012 Argonne National Laboratory
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

=========================================================================*/


/*
BG/Q tuned version of HACC: 69.2% of peak performance on 96 racks of Sequoia
Argonne Leadership Computing Facility, Argonne, IL 60439
Vitali Morozov (morozov@anl.gov)
Hal Finkel (hfinkel@anl.gov)
*/


#include "Timings.h"
#include "RCBForceTree.h"
#include "Partition.h"
#include "nBody.h"
#include "gpu.h"
#include "SimpleTimings.h"

#include <atomic>
#include <cassert>
#include <cfloat>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <omp.h>
#include <stdexcept>
using namespace std;

// Note: In Gafton and Rosswog the far-field force contribution is calculated
// per-cell (at the center of mass), and then a Taylor expansion about the center
// of mass is used to calculate the force on the individual particles. For this to
// work, the functional form of the force must be known (because the Jacobian
// and Hessian are required). Here, however, the functional form is not known,
// and so the pseudo-particle method of Makino is used instead.

static void init(TreeNode *const node, const int count, const int offset, const int parent)
{
  node->count = count;
  node->offset = offset;
  node->parent = parent;
  node->cl = node->cr = 0;
  node->xmin[0] = node->xmin[1] = node->xmin[2] = FLT_MAX;
  node->xmax[0] = node->xmax[1] = node->xmax[2] = -FLT_MAX;
  node->xc[0] = node->xc[1] = node->xc[2] = 0.0f;
}

RCBForceTree::RCBForceTree(
			 float* minLoc,
			 float* maxLoc,
			 float* minForceLoc,
			 float* maxForceLoc,
			 long count,
                         Device &gpu,
			 float avgMass,
                         float fsm,
                         float r,
                         float oa,
                         long nd,
                         long ds,
                         long tmin,
			 ForceLaw *fl,
			 float fcoeff,
                         float ppc):
                           gpu(gpu)
{
  // Extract the contiguous data block from a vector pointer
  particleCount = count;

  particleMass = avgMass;
  fsrrmax = fsm;
  rsm = r;
  sinOpeningAngle = sinf(oa);
  tanOpeningAngle = tanf(oa);
  nDirect = nd;
  depthSafety = ds;
  taskPartMin = tmin;
  ppContract = ppc;

  // Find the grid size of this chaining mesh
  for (int dim = 0; dim < DIMENSION; dim++) {
    minRange[dim] = minLoc[dim];
    maxRange[dim] = maxLoc[dim];
    minForceRange[dim] = minForceLoc[dim];
    maxForceRange[dim] = maxForceLoc[dim];
  }

  if (fl) {
    m_own_fl = false;
    m_fl = fl;
    m_fcoeff = fcoeff;
  } else {
    //maybe change this to Newton's law or something
    m_own_fl = true;
    m_fl = new ForceLawNewton();
    m_fcoeff = 1.0;
  }

  timespec b_start, b_end;
  clock_gettime(CLOCK_THREAD_CPUTIME_ID, &b_start);
  grow();
  CHECK(hipMemcpy(gpu.statsH,gpu.statsD,sizeof(TreeStats),hipMemcpyDeviceToHost));
  clock_gettime(CLOCK_THREAD_CPUTIME_ID, &b_end);
  nBody(gpu,m_fcoeff,fsrrmax,rsm*rsm);
  double b_time = (b_end.tv_sec - b_start.tv_sec);
  b_time += 1e-9*(b_end.tv_nsec - b_start.tv_nsec);
  printStats(b_time);
}

RCBForceTree::~RCBForceTree()
{
  if (m_own_fl) {
    delete m_fl;
  }
}

void RCBForceTree::printStats(double buildTime)
{
  const TreeStats &stats = *gpu.statsH;
  double localParticleCount = particleCount;
  double localTreeSize = *gpu.nNodes;
  double localTreeCapacity = gpu.maxNodes;
  double localLeaves = stats.zeroLeafNodes+stats.nonzeroLeafNodes;
  double localEmptyLeaves = stats.zeroLeafNodes;
  double localMeanPPN = stats.leafParts/((double) stats.nonzeroLeafNodes);
  unsigned int localMaxPPN = stats.maxPPN;
  double localBuildTime = buildTime;

  if ( Partition::getMyProc() == 0 ) {
    printf("\ttree post-build statistics (local for rank 0):\n");
    printf("\t\tparticles: %.2f\n", localParticleCount);
    printf("\t\tnodes: %.2f (allocated:  %.2f)\n", localTreeSize, localTreeCapacity);
    printf("\t\tleaves: %.2f (empty: %.2f)\n", localLeaves, localEmptyLeaves);
    printf("\t\tmean ppn: %.2f (max ppn: %u)\n", localMeanPPN, localMaxPPN);
    printf("\t\tbuild time: %g s\n", localBuildTime);
  }
}

__attribute__((unused))
static void compare(const char *const name, const int n, const float *const v, const float *const u)
{
  float vsum = 0;
  float v2sum = 0;
  float vmax = 0;
  float dsum = 0;
  float d2sum = 0;
  float dmax = 0;
  for (int i = 0; i < n; i++) {
    const float vi = fabs(v[i]);
    const float di = fabs(v[i]-u[i]);
    vsum += vi;
    v2sum += vi*vi;
    vmax = (vmax < vi) ? vi : vmax;
    dsum += di;
    d2sum += di*di;
    dmax = (dmax < di) ? di : dmax;
  }
  printf("%s: l1 %g l2 %g linf %g\n",name,dsum/vsum,sqrtf(d2sum/v2sum),dmax/vmax);
}

template <typename T>
void swap(T *__restrict const p, T *__restrict const q)
{
  const T t = *p;
  *p = *q;
  *q = t;
}

void RCBForceTree::grow()
{
  CHECK(hipMemsetAsync(gpu.njs,0,2*gpu.maxNodes*sizeof(int),0)); // also zeros nks
  CHECK(hipMemsetAsync(gpu.swap,0,particleCount*sizeof(int),0));
  CHECK(hipMemsetAsync(gpu.nlD,0,gpu.maxNodes*sizeof(int),0));
  CHECK(hipMemsetAsync(gpu.statsD,0,sizeof(TreeStats),0));
  *gpu.nNodes = 1;
  CHECK(hipMemcpyAsync(gpu.nNodesD,gpu.nNodes,sizeof(int),hipMemcpyHostToDevice,0));
  init(gpu.tree,particleCount,0,0);
  CHECK(hipMemcpyAsync(gpu.treeD,gpu.tree,sizeof(TreeNode),hipMemcpyHostToDevice,0));
  int iBegin = 0;

  while (iBegin < *gpu.nNodes) {
    const int iLo = iBegin;
    const int iHi = *gpu.nNodes;
    iBegin = iHi;
    centersOfMassD(iLo,iHi);
    partitionsD(iLo,iHi);
  }

  assert(*gpu.nNodes <= gpu.maxNodes);
}


