#include "Device.h"
#include "gpu.h"
#include <cmath>
#include <hipcub/hipcub.hpp>

Device::Device():
  particleBytes(0),
  xyzBytes(0),
  xx(nullptr),
  yy(nullptr),
  zz(nullptr),
  vx(nullptr),
  vy(nullptr),
  vz(nullptr),
  more(nullptr),
  maxNodes(0),
  tree(nullptr),
  treeD(nullptr),
  nNodes(nullptr),
  statsH(nullptr),
  leavesD(nullptr),
  nNodesD(nullptr),
  statsD(nullptr),
  nlD(nullptr),
  njs(nullptr),
  nks(nullptr),
  swap(nullptr),
  tmpA(nullptr),
  tmpB(nullptr),
  cubBytes(0),
  cubTmp(nullptr)
{}

Device::~Device()
{
  dropParticles();
}

void Device::allocateParticles(const int n, const int ng, const int nDirect, const size_t parisBytes)
{
  if (particleBytes) dropParticles();
  ppn = nDirect;
  particleBytes = 6*n*sizeof(float);
  xyzBytes = 3*n*sizeof(float);
  CHECK(hipMalloc(&xx,particleBytes));
  CHECK(hipMemset(xx,0,particleBytes));
  yy = xx+n;
  zz = yy+n;
  vx = zz+n;
  vy = vx+n;
  vz = vy+n;

  const size_t aBytes = std::max({parisBytes,n*sizeof(long),n*sizeof(int)+(ng+1)*sizeof(int)});
  CHECK(hipMalloc(&tmpA,aBytes));
  const size_t bBytes = std::max({parisBytes,n*sizeof(int),(ng+1)*sizeof(int)});
  CHECK(hipMalloc(&tmpB,bBytes));

  static constexpr double nodeCoeff = 0.00038;
  maxNodes = nodeCoeff*double(n)*log(double(n))+2000; 
  const int halfNodes = maxNodes/2+1;

  treeD = reinterpret_cast<TreeNode*>(tmpA);
  size_t bytes = maxNodes*sizeof(TreeNode);
  assert(bytes <= aBytes);
  leavesD = reinterpret_cast<int*>(tmpA+bytes);
  nNodesD = leavesD+halfNodes;
  nlD = nNodesD+1;
  bytes += (maxNodes+halfNodes+1)*sizeof(int);
  assert(bytes <= aBytes);
  statsD = reinterpret_cast<TreeStats*>(tmpA+bytes);
  bytes += sizeof(TreeStats);
  assert(bytes <= aBytes);
  more = tmpA+bytes;
  bytes += n*sizeof(char);
  assert(bytes <= aBytes);

  assert((2*maxNodes+n)*sizeof(int) <= bBytes);
  njs = reinterpret_cast<int*>(tmpB);
  nks = njs+maxNodes;
  swap = nks+maxNodes;

  CHECK(hipcub::DeviceScan::ExclusiveSum(nullptr,cubBytes,reinterpret_cast<int*>(tmpA),reinterpret_cast<int*>(tmpB),ng+1));
  CHECK(hipMalloc(&cubTmp,cubBytes));

  CHECK(hipHostMalloc(&tree,sizeof(TreeNode)));
  CHECK(hipHostMalloc(&nNodes,sizeof(int)));
  CHECK(hipHostMalloc(&statsH,sizeof(TreeStats)));
}

void Device::dropParticles()
{
  CHECK(hipHostFree(statsH));
  statsH = nullptr;
  CHECK(hipHostFree(nNodes));
  nNodes = nullptr;
  CHECK(hipHostFree(tree));
  tree = nullptr;
  maxNodes = 0;

  CHECK(hipFree(cubTmp));
  cubTmp = nullptr;
  cubBytes = 0;

  CHECK(hipFree(tmpB));
  tmpB = nullptr;
  njs = nks = swap = nullptr;

  CHECK(hipFree(tmpA));
  tmpA = nullptr;
  treeD = nullptr;
  leavesD = nNodesD = nullptr;
  nlD = nullptr;
  statsD = nullptr;
  more = nullptr;

  CHECK(hipFree(xx));
  particleBytes = xyzBytes = 0;
  xx = yy = zz = vx = vy = vz = nullptr;
}

