#include <assert.h>
#include <math.h>
#include <stdlib.h>

void Step16_int( const int count1, const float xxi, const float yyi, const float zzi, const float fsrrmax2, const float mp_rsm2, const float *restrict const xx1, const float *restrict const yy1, const float *restrict const zz1, const float *restrict const mass1, float *restrict const ax, float *restrict const ay, float *restrict const az )
{
  const float ma0 = 0.269327f, ma1 = -0.0750978f, ma2 = 0.0114808f, ma3 = -0.00109313f, ma4 = 0.0000605491f, ma5 = -0.00000147177f;
  for ( int k = 0; k < count1; k++ ) 
  {
    const float dxc = xx1[k] - xxi;
    const float dyc = yy1[k] - yyi;
    const float dzc = zz1[k] - zzi;

    const float r2 = dxc * dxc + dyc * dyc + dzc * dzc;

    const float m = ( r2 < fsrrmax2 ) ? mass1[k] : 0.0f;

    const float s0 = r2 + mp_rsm2;
    const float s1 = s0 * s0 * s0;
    const float s2 = 1.0f / sqrtf( s1 ) - ( ma0 + r2*(ma1 + r2*(ma2 + r2*(ma3 + r2*(ma4 + r2*ma5)))));

    const float f = ( r2 > 0.0f ) ? m * s2 : 0.0f;

    *ax += f * dxc;
    *ay += f * dyc;
    *az += f * dzc;
  }
}

