#pragma once
#include "BasicDefinition.h"
#include <cstddef>

struct TreeNode { int count,offset,parent,cl,cr; float xmin[3],xmax[3],xc[3]; };

struct TreeStats { int nLeaves,zeroLeafNodes,nonzeroLeafNodes,maxPPN,leafParts; };

struct Device {
  Device();
  ~Device();
  void allocateParticles(int n, int ng, int nDirect, size_t parisBytes);
  void dropParticles();

  long particleBytes;
  long xyzBytes;

  float *xx;
  float *yy;
  float *zz;
  float *vx;
  float *vy;
  float *vz;

  char *more;

  int maxNodes;
  int ppn;
  TreeNode *tree;
  TreeNode *treeD;
  int *nNodes;
  TreeStats *statsH;
  int *leavesD;
  int *nNodesD;
  TreeStats *statsD;
  int *nlD;
  int *njs;
  int *nks;
  int *swap;

  char *tmpA;
  char *tmpB;

  size_t cubBytes;
  char *cubTmp;
};

