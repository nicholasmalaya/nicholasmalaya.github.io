#pragma once
#include "Device.h"
void nBody(Device &gpu, float fCoeff, float fsrrMax, float rsm2);

