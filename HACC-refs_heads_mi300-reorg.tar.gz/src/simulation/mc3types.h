#ifndef MC3_TYPES_H
#define MC3_TYPES_H

#ifdef POSVEL_64

#define FLOOR floor
#define CEIL ceil

#else

#define FLOOR floorf
#define CEIL ceilf

#endif

#endif
