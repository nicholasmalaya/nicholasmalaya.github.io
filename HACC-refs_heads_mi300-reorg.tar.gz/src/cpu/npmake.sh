#!/bin/bash
module load PrgEnv-cray cray-fftw gcc perftools-lite

export MPI_HOME=$(echo $PATH | sed 's,\(^\|.*:\)\([^:]*mvapich2[^:]*\)/bin.*,\2,')
echo $MPI_HOME

export HACC_PLATFORM="redwood-cuda"
export HACC_OBJDIR="${HACC_PLATFORM}"

ompflg="-fopenmp"

export HACC_CC=cc
export HACC_CXX=CC
export HACC_MPI_CC=$HACC_CC
export HACC_MPI_CXX=$HACC_CXX
export HACC_GPU_CXX=nvcc

export HACC_CFLAGS="-g -Ofast ${ompflg} -fsave-loopmark -Wall -Werror -ferror-limit=1 -Wno-unused-function"

export HACC_CXXFLAGS="${HACC_CFLAGS} -std=c++17 -DO_CUDA -I${CUDA_HOME}/include"
export HACC_MPI_CFLAGS=$HACC_CFLAGS
export HACC_MPI_CXXFLAGS=$HACC_CXXFLAGS
export HACC_GPU_CXXFLAGS="-DO_CUDA -x cu -g -O3 -std=c++14 -arch sm_70 --expt-extended-lambda -I${MPI_HOME}/include"

export HACC_LD="${HACC_CXX}"
export HACC_LDFLAGS="${HACC_CXXFLAGS} -L${CUDA_HOME}/lib -L${CUDA_HOME}/extras/CUPTI/lib64 -lcudart"

export FFTW_MAJOR_VERSION=3

# currently "omp" turns on fftw omp threads
# any other value turns off fftw omp threads, eg. "none"
export FFTW_THREADING=omp

use_essl=no
if [ "x$use_essl" = xyes ]; then
export FFTW_WRAPPER=essl
export ESSL_LIBDIR=/home/morozov/ESSL5.1.1-20120305 
export XLF_LIBDIR=${COMPILER_PATH}/xlf/bg/14.1/bglib64
root=/gpfs/mira-home/morozov/Work/ALCF3/CoralApps/HACC/src/essl_fftw

export FFTW_HOME=${root}
export FFTW_INCLUDE=${root}/include
export CPATH=${root}/include:${CPATH}
if [ -f ${root}/bglib64 ] 
then
export LD_LIBRARY_PATH=${root}/bglib64:${LD_LIBRARY_PATH}
else
export LD_LIBRARY_PATH=${root}/bglib:${LD_LIBRARY_PATH}
fi

else

root=${FFTW_ROOT}

export FFTW_HOME=${root}
export FFTW_INCLUDE=${root}/include
export CPATH=${root}/include:${CPATH}
if [ -f ${root}/lib64 ] 
then
export LD_LIBRARY_PATH=${root}/lib64:${LD_LIBRARY_PATH}
else
export LD_LIBRARY_PATH=${root}/lib:${LD_LIBRARY_PATH}
fi
export INFOPATH=${root}/share/info:${INFOPATH}
export MANPATH=${root}/share/man:$MANPATH
export PATH=${root}/bin:${PATH}

fi

cd ../halo_finder/${HACC_PLATFORM}
rm -rf libB*.a
cd -
cd ..
make clean
cd -
make
