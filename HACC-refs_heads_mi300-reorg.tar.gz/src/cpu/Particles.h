//-*-C++-*-//////////////////////////////////////////////////////////////////
// $Id: Particles.h,v 1.5 2010/08/06 20:37:28 pope Exp $
/////////////////////////////////////////////////////////////////////////////

#ifndef PARTICLES_H
#define PARTICLES_H

#include <cassert>
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <sys/time.h>

#include <stdlib.h>
#include <string.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#include "Definition.h"
#include "mc3types.h"
#include "Basedata.h"
#include "array_index.h"
#include "Domain.h"
#include "TimeStepper.h"
#include "SimpleTimings.h"
#include "MC3Options.h"
#include "ForceLaw.h"
#include "BHForceTree.h"
#include "RestartIO.h"
#include "Partition.h"
#include "Device.h"
#include "gpu.h"


#define MEM_ALIGN 64
#define N_POSVEL_T 8



class CMLite
{
public:

  CMLite(int ngx, int ngy, int ngz);
  ~CMLite();

  int ng[DIMENSION];
  int Ng;
  int *indxlo;
  int *indxhi;
};


class Particles
{
public:

  Particles(const Basedata &, MC3Options & options, size_t parisBytes);
  ~Particles();

  const Device &gpu() { return m_gpu; }
  float *field() {return m_field; }
  float *fieldD() { return m_fieldD; }
  int Np_local_total() { return m_Np_local_total; }
  int Np_local_alive();
  int npLocalAliveD();

  void startSumD();

  void copyFieldFromDevice();
  void copyFromDevice();
  void copyToDevice();

  vector<unsigned int> *aliveIndices();

  void copyAllFromVectors(vector<float> **xx,
			  vector<float> **yy,
			  vector<float> **zz,
			  vector<float> **vx,
			  vector<float> **vy,
			  vector<float> **vz,
			  vector<float> **phi,
			  vector<long> **id,
			  vector<MASK_T> **mask,
			  float anow,
			  int deleteVectorsQ=0);

  void copyAliveIntoVectors(vector<float> *xx,
			    vector<float> *yy,
			    vector<float> *zz,
			    vector<float> *vx,
			    vector<float> *vy,
			    vector<float> *vz,
			    vector<float> *phi,
			    vector<long> *id,
			    vector<MASK_T> *mask,
			    float anow,
			    int npr=0,
			    int dropParticlesQ=0);


  void shoveParticles() {return;};
  void grabParticles() {return;};
  void dropParticles();
  void resortParticles();
  void resortParticlesD();
  void allocField();

  void writeAliveHCosmo( const char *outName, float anow );
  void writeRestart(const char *outName);
  void readRestart(const char *inName);

  void map1(float pp, float tau, float adot);
  void map1d(float pp, float tau, float adot);
  void cic();
  void cicd();
  void inverse_cic(float tau, float fscal, int comp);
  void inverseCICD(float tau, float scale, int d);
  void inverseCIC3D(float tau, float scale);
  void inverse_cic_potential();

  FGrid *f_grid_over_r;
  void loadInterp(int n, float *x, float *y);
  void forceInterp(uint32_t nInterp);

  void subCycle(TimeStepper *gts);
  void map2(TimeStepper *ts, TS_FLOAT stepFraction=1.0);

  void buildChainingMesh();
  void subCycleCM(TimeStepper *gts);
  void map2CM(TimeStepper *ts, TS_FLOAT stepFraction=1.0);

  void writeRawAscii(const char * fname );

private:

  Particles();
  Particles( const Particles& );
  Particles& operator = ( const Particles& );

  void coords_global2local(float anow);
  void coords_local2global(float anow);

  void allocParticles(int Np);

  int array_index(int xx, int yy, int zz, 
		  int ng[], int lo[], int hi[],
		  int safe);


  long *m_idArr;
  float *m_xArr;
  float *m_yArr;
  float *m_zArr;
  float *m_vxArr;
  float *m_vyArr;
  float *m_vzArr;
  float *m_massArr;
  float *m_phiArr;
  MASK_T *m_maskArr;

  Device m_gpu;
  hipStream_t m_copyStream, m_runStream;

  float *m_field;
  float *m_fieldD;

  int m_Np_local_total;
  int m_Np_last;

  float m_alpha;
  float m_gpscal;

  int m_coords_localQ;

  int m_nsub;
  float m_edge;
  float m_rsm;
  float m_fsrrmax;
  float m_cmsize;
  float m_openAngle;

  CMLite *m_cm;

  FGrid *m_fg;
  FGridEval *m_fgore;

  ForceLaw *m_fl;

  int m_skipStreamQ;
  int m_skipKickSRQ;
  int m_useFastTreeEval;
  int m_useSymmTree;
  int m_useRCBTree;
  int m_rcbTreeExtraLevels;
  int m_rcbTreePPN;
  int m_rcbTreeTaskPartMin;

  int m_mpiio;
  size_t m_parisBytes;
};



#endif

