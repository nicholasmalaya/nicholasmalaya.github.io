#include "Particles.h"
#include "gpu.h"

#include <cmath>
#include <hipcub/hipcub.hpp>

__launch_bounds__(gpuBlockSize) __global__
static void cicg(const int n, const int ni, const int nj, const int nk, const float c, const float *__restrict const xx, const float *__restrict const yy, const float *__restrict const zz, float *const field)
{
  const int njk = nj*nk;
  const int offset = threadIdx.x+blockDim.x*blockIdx.x;
  const int stride = blockDim.x*gridDim.x;

  for (int p = offset; p < n; p += stride) {

    const float x = xx[p];
    const float y = yy[p];
    const float z = zz[p];

    const float fx = std::floor(x);
    const float fy = std::floor(y);
    const float fz = std::floor(z);

    const int i(fx);
    const int j(fy);
    const int k(fz);

    const int i1 = i+1;
    const int j1 = j+1;
    const int k1 = k+1;

    const float ab = 1.0f+(fx-x);
    const float de = 1.0f+(fy-y);
    const float gh = 1.0f+(fz-z);

    const float cab = c*ab;
    const float cab1 = c*(1.0f-ab);
    const float de1 = 1.0f-de;
    const float gh1 = 1.0f-gh;

    const float cabde = cab*de;
    const float cabde1 = cab*de1;
    const float cab1de = cab1*de;
    const float cab1de1 = cab1*de1;

    const int ijk = (i*nj+j)*nk+k;

    const bool iok = ((i >= 0) && (i < ni));
    const bool i1ok = ((i1 >= 0) && (i1 < ni));
    const bool jok = ((j >= 0) && (j < nj));
    const bool j1ok = ((j1 >= 0) && (j1 < nj));
    const bool kok = ((k >= 0) && (k < nk));
    const bool k1ok = ((k1 >= 0) && (k1 < nk));

    if (iok && jok && kok) atomicAdd(field+ijk,cabde*gh);
    if (iok && jok && k1ok) atomicAdd(field+ijk+1,cabde*gh1);
    if (iok && j1ok && kok) atomicAdd(field+ijk+nk,cabde1*gh);
    if (iok && j1ok && k1ok) atomicAdd(field+ijk+nk+1,cabde1*gh1);
    if (i1ok && jok && kok) atomicAdd(field+ijk+njk,cab1de*gh);
    if (i1ok && jok && k1ok) atomicAdd(field+ijk+njk+1,cab1de*gh1);
    if (i1ok && j1ok && kok) atomicAdd(field+ijk+njk+nk,cab1de1*gh);
    if (i1ok && j1ok && k1ok) atomicAdd(field+ijk+njk+nk+1,cab1de1*gh1);
  }
}

void Particles::cicd() {
  assert(m_coords_localQ == 1);

  const int n = Domain::Ng_local_total();
  const size_t bytes = n*sizeof(float);
  CHECK(hipMemsetAsync(m_fieldD,0,bytes,0));

  int ng[3];
  Domain::ng_local_total(ng);
  const int ni = ng[0];
  const int nj = ng[1];
  const int nk = ng[2];

  const float c = m_gpscal*m_gpscal*m_gpscal;

  const int nb = (m_Np_local_total+gpuBlockSize-1)/gpuBlockSize;
  hipLaunchKernelGGL(cicg,nb,gpuBlockSize,0,0,m_Np_local_total,ni,nj,nk,c,m_gpu.xx,m_gpu.yy,m_gpu.zz,m_fieldD);
  CHECK(hipGetLastError());
}

__global__ __launch_bounds__(1024)
static void sumG(const int ngo, const int ni, const int nj, const int nk, const int di, const int dj, float *const field)
{
  __shared__ float sum;
  const bool root = (threadIdx.x == 0) && (threadIdx.y == 0) && (threadIdx.z == 0);
  if (root) sum = 0.0f;
  __syncthreads();
  const int i = ngo+threadIdx.x+blockIdx.x*blockDim.x;
  const int j = ngo+threadIdx.y+blockIdx.y*blockDim.y;
  const int k = ngo+threadIdx.z+blockIdx.z*blockDim.z;
  if ((i < ni) && (j < nj) && (k < nk)) {
    const int ijk = i+di*j+dj*k;
    atomicAdd(&sum,field[ijk]);
  }
  __syncthreads();
  if (root) atomicAdd(field,sum);
}

void Particles::startSumD()
{
  CHECK(hipMemsetAsync(m_fieldD,0,sizeof(float),0));

  const int ngo = Domain::ng_overload();
  int ngla[DIMENSION], nglt[DIMENSION];
  Domain::ng_local_alive(ngla);
  Domain::ng_local_total(nglt);

  const dim3 block(16,8,8);
  const dim3 grid((ngla[2]+block.x-1)/block.x,(ngla[1]+block.y-1)/block.y,(ngla[0]+block.z-1)/block.z);
  sumG<<<grid,block>>>(ngo,ngla[2]+ngo,ngla[1]+ngo,ngla[0]+ngo,nglt[2],nglt[2]*nglt[1],m_fieldD);
  CHECK(hipGetLastError());
  CHECK(hipMemcpyAsync(m_field,m_fieldD,sizeof(float),hipMemcpyDeviceToHost,0));
}

static constexpr float twelfth = 1.0/12.0;

__launch_bounds__(gpuBlockSize) __global__
static void inverseCIC3G(const int np, const int ni, const int nj, const int nk, const float *const xx, const float *const yy, const float *const zz, const float *const phi, const float tau, const float scale, float *__restrict const vx, float *__restrict const vy, float *__restrict const vz)
{
  const int p = threadIdx.x+blockIdx.x*blockDim.x;
  if (p < np) {

    const float x = xx[p];
    const float y = yy[p];
    const float z = zz[p];

    const int i = std::floor(x);
    const int j = std::floor(y);
    const int k = std::floor(z);

    const int i1 = i+1;
    const int j1 = j+1;
    const int k1 = k+1;

    const float ab = 1.0f+(i-x);
    const float de = 1.0f+(j-y);
    const float gh = 1.0f+(k-z);

    const float ab1 = 1.0f-ab;
    const float de1 = 1.0f-de;
    const float gh1 = 1.0f-gh;

    const float abde = ab*de;
    const float abde1 = ab*de1;
    const float ab1de = ab1*de;
    const float ab1de1 = ab1*de1;

    const int dk = nk+4;
    const int dk2 = dk+dk;
    const int dj = nj+4;
    const int djk = dj*dk;
    const int djk2 = djk+djk;
    const int dijk = k+2+dk*(j+2)+djk*(i+2);

    const bool iok = ((i >= 0) && (i < ni));
    const bool i1ok = ((i1 >= 0) && (i1 < ni));
    const bool jok = ((j >= 0) && (j < nj));
    const bool j1ok = ((j1 >= 0) && (j1 < nj));
    const bool kok = ((k >= 0) && (k < nk));
    const bool k1ok = ((k1 >= 0) && (k1 < nk));

    float fx = 0;
    float fy = 0;
    float fz = 0;
    if (iok && jok && kok) {
      const float abdegh = abde*gh;
      const int q = dijk;
      fx += abdegh*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += abdegh*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += abdegh*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (iok && jok && k1ok) {
      const float abdegh1 = abde*gh1;
      const int q = dijk+1;
      fx += abdegh1*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += abdegh1*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += abdegh1*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (iok && j1ok && kok) {
      const float abde1gh = abde1*gh;
      const int q = dijk+dk;
      fx += abde1gh*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += abde1gh*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += abde1gh*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (iok && j1ok && k1ok) {
      const float abde1gh1 = abde1*gh1;
      const int q = dijk+dk+1;
      fx += abde1gh1*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += abde1gh1*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += abde1gh1*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (i1ok && jok && kok) {
      const float ab1degh = ab1de*gh;
      const int q = dijk+djk;
      fx += ab1degh*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += ab1degh*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += ab1degh*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (i1ok && jok && k1ok) {
      const float ab1degh1 = ab1de*gh1;
      const int q = dijk+djk+1;
      fx += ab1degh1*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += ab1degh1*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += ab1degh1*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (i1ok && j1ok && kok) {
      const float ab1de1gh = ab1de1*gh;
      const int q = dijk+djk+dk;
      fx += ab1de1gh*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += ab1de1gh*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += ab1de1gh*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    if (i1ok && j1ok && k1ok) {
      const float ab1de1gh1 = ab1de1*gh1;
      const int q = dijk+djk+dk+1;
      fx += ab1de1gh1*(phi[q+djk2]-8.0f*phi[q+djk]+8.0f*phi[q-djk]-phi[q-djk2])*twelfth;
      fy += ab1de1gh1*(phi[q+dk2]-8.0f*phi[q+dk]+8.0f*phi[q-dk]-phi[q-dk2])*twelfth;
      fz += ab1de1gh1*(phi[q+2]-8.0f*phi[q+1]+8.0f*phi[q-1]-phi[q-2])*twelfth;
    }
    vx[p] += fx*tau*scale;
    vy[p] += fy*tau*scale;
    vz[p] += fz*tau*scale;
  }
}

void Particles::inverseCIC3D(const float tau, const float scale)
{
  assert(m_coords_localQ == 1);
  int ng[DIMENSION];
  Domain::ng_local_total(ng);
  const int np = m_Np_local_total;
  const int nb = (np+gpuBlockSize-1)/gpuBlockSize;
  inverseCIC3G<<<nb,gpuBlockSize>>>(np,ng[0],ng[1],ng[2],m_gpu.xx,m_gpu.yy,m_gpu.zz,m_fieldD,tau,scale,m_gpu.vx,m_gpu.vy,m_gpu.vz);
  CHECK(hipGetLastError());
  CHECK(hipMemcpyAsync(m_vxArr,m_gpu.vx,3*np*sizeof(float),hipMemcpyDeviceToHost,0));
}


__launch_bounds__(gpuBlockSize) __global__
static void mapG(const long n, const float pt, const float *__restrict const vx, const float *__restrict const vy, const float *__restrict const vz, float *__restrict const xx, float *__restrict const yy, float *__restrict const zz)
{
  const long offset = threadIdx.x+blockDim.x*long(blockIdx.x);
  const long stride = blockDim.x*long(gridDim.x);
  for (long i = offset; i < n; i += stride) {
    xx[i] += pt*vx[i];
    yy[i] += pt*vy[i];
    zz[i] += pt*vz[i];
  }
}

void Particles::map1d(const float pp, const float tau, const float aDot)
{
  assert(m_coords_localQ == 1);
  const float pf = powf(pp,(1.0f+1.0f/m_alpha));
  const float prefactor = 1.0f/(m_alpha*aDot*pf);
  const float pt = prefactor*tau;
  const int nb = (m_Np_local_total+gpuBlockSize-1)/gpuBlockSize;
  hipLaunchKernelGGL(mapG,nb,gpuBlockSize,0,0,m_Np_local_total,pt,m_gpu.vx,m_gpu.vy,m_gpu.vz,m_gpu.xx,m_gpu.yy,m_gpu.zz);
  CHECK(hipGetLastError());
}

__launch_bounds__(gpuMaxThreads) __global__
static void bringOutYourDeadG(const int n, const float lo, const float hiX, const float hiY, const float hiZ, const float *const xx, const float *const yy, const float *const zz, int *const countG)
{
  __shared__ int countS;
  if (threadIdx.x == 0) countS = 0;
  const int i = threadIdx.x+blockIdx.x*blockDim.x;
  __syncthreads();
  if (i < n) {
    const float xxi = xx[i];
    const float yyi = yy[i];
    const float zzi = zz[i];
    if ((xxi < lo) || (yyi < lo) || (zzi < lo) || (xxi >= hiX) || (yyi >= hiY) || (zzi >= hiZ)) atomicAdd(&countS,1);
  }
  __syncthreads();
  if ((threadIdx.x == 0) && (countS > 0)) atomicAdd(countG,countS);
}


int Particles::npLocalAliveD()
{
  assert(m_coords_localQ == 1);
  const float lo = Domain::ng_overload();
  int ngla[DIMENSION];
  Domain::ng_local_alive(ngla);
  const float hiX = lo+ngla[0];
  const float hiY = lo+ngla[1];
  const float hiZ = lo+ngla[2];
  const int nb = (m_Np_local_total+gpuMaxThreads-1)/gpuMaxThreads;
  CHECK(hipMemsetAsync(m_gpu.nNodes,0,sizeof(int),0));
  bringOutYourDeadG<<<nb,gpuMaxThreads>>>(m_Np_local_total,lo,hiX,hiY,hiZ,m_gpu.xx,m_gpu.yy,m_gpu.zz,m_gpu.nNodes);
  CHECK(hipGetLastError());
  int nDead = 0;
  CHECK(hipMemcpy(&nDead,m_gpu.nNodes,sizeof(int),hipMemcpyDeviceToHost));
  return m_Np_local_total-nDead;
}


__launch_bounds__(gpuBlockSize) __global__
static void countG(const int np, const int nx, const int ny, const int nz, const int ngTotal, const float *const xx, const float *const yy, const float *const zz, int *const __restrict__ ix, int *const __restrict__ count)
{
  const int p = blockDim.x*blockIdx.x+threadIdx.x;
  if (p < np) {
    const int i = std::floor(xx[p]);
    const int j = std::floor(yy[p]);
    const int k = std::floor(zz[p]);
    const bool safe = (i >= 0) && (j >= 0) && (k >= 0) && (i < nx) && (j < ny) && (k < nz);
    const int ijk = safe ? (i*ny+j)*nz+k : ngTotal;
    ix[p] = ijk;
    atomicAdd(count+ijk,1);
  }
}

__launch_bounds__(gpuBlockSize) __global__
static void indexG(const int n, const int *const ix, int *const __restrict__ scan, int *const __restrict jx)
{
  const int p = blockDim.x*blockIdx.x+threadIdx.x;
  if (p < n) jx[atomicAdd(scan+ix[p],1)] = p;
}

template <typename A, typename B>
__launch_bounds__(gpuBlockSize) __global__
static void rearrangeG(const int n, const int *const jx, const A *const inA, const B *const inB, A *const __restrict__ outA, B *const __restrict outB)
{
  const int p = blockDim.x*blockIdx.x+threadIdx.x;
  if (p < n) {
    const int j = jx[p];
    outA[p] = inA[j];
    outB[p] = inB[j];
  }
}

void Particles::resortParticlesD() {

  int ng[3] = {0,0,0};
  Domain::ng_local_total(ng);
  const int ngTotal = Domain::Ng_local_total();

  int *const ix = reinterpret_cast<int*>(m_gpu.tmpA);
  int *const scan = ix+m_Np_local_total;
  int *const count = reinterpret_cast<int*>(m_gpu.tmpB);

  const int nbp = (m_Np_local_total+gpuBlockSize-1)/gpuBlockSize;
  CHECK(hipMemsetAsync(count,0,(ngTotal+1)*sizeof(int),0));
  countG<<<nbp,gpuBlockSize>>>(m_Np_local_total,ng[0],ng[1],ng[2],ngTotal,m_gpu.xx,m_gpu.yy,m_gpu.zz,ix,count);
  CHECK(hipGetLastError());

  CHECK(hipcub::DeviceScan::ExclusiveSum(m_gpu.cubTmp,m_gpu.cubBytes,count,scan,ngTotal+1));
  int scanBack = 0;
  CHECK(hipMemcpyAsync(&scanBack,count+ngTotal,sizeof(int),hipMemcpyDeviceToHost,0));
  hipEvent_t backDone;
  CHECK(hipEventCreate(&backDone));
  CHECK(hipEventRecord(backDone,0));

  int *const jx = count;
  indexG<<<nbp,gpuBlockSize>>>(m_Np_local_total,ix,scan,jx);
  CHECK(hipGetLastError());

  float *const fpa = reinterpret_cast<float*>(m_gpu.tmpA);
  float *const fpb = fpa+m_Np_local_total;
  const size_t fBytes = m_Np_local_total*sizeof(float);
  const size_t ffBytes = 2*fBytes;

  CHECK(hipMemcpyAsync(fpa,m_gpu.xx,ffBytes,hipMemcpyDeviceToDevice,0));
  rearrangeG<<<nbp,gpuBlockSize>>>(m_Np_local_total,jx,fpa,fpb,m_gpu.xx,m_gpu.yy);
  CHECK(hipGetLastError());

  CHECK(hipMemcpyAsync(fpa,m_gpu.zz,ffBytes,hipMemcpyDeviceToDevice,0));
  rearrangeG<<<nbp,gpuBlockSize>>>(m_Np_local_total,jx,fpa,fpb,m_gpu.zz,m_gpu.vx);
  CHECK(hipGetLastError());

  CHECK(hipMemcpyAsync(fpa,m_gpu.vy,ffBytes,hipMemcpyDeviceToDevice,0));
  rearrangeG<<<nbp,gpuBlockSize>>>(m_Np_local_total,jx,fpa,fpb,m_gpu.vy,m_gpu.vz);
  CHECK(hipGetLastError());

  CHECK(hipEventSynchronize(backDone));
  CHECK(hipEventDestroy(backDone));
  m_Np_last = m_Np_local_total-scanBack;
}


