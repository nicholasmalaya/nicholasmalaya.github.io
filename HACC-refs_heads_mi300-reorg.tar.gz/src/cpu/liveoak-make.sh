#!/bin/bash
module load rocm
module load cray-fftw
module list

export HACC_PLATFORM=liveoak
export HACC_OBJDIR="${HACC_PLATFORM}"

ompflg="-fopenmp"

export HACC_CC=hipcc
export HACC_CXX=hipcc
export HACC_MPI_CC="${HACC_CC}"
export HACC_MPI_CXX="${HACC_CXX}"
export HACC_GPU_CXX=hipcc

export HACC_CFLAGS="-Wall -Wno-unused-result -g -O3 ${ompflg} -I${FFTW_INC}"

export HACC_CXXFLAGS="-DO_HIP -DPARIS_HACC ${HACC_CFLAGS} -std=c++17 -I${ROCM_PATH}/hipfft/include"
export HACC_MPI_CFLAGS="${HACC_CFLAGS} -I${CRAY_MPICH_PREFIX}/include"
export HACC_MPI_CXXFLAGS="${HACC_CXXFLAGS} -I${CRAY_MPICH_PREFIX}/include"
export HACC_GPU_CXXFLAGS="${HACC_MPI_CXXFLAGS} --offload-arch=gfx90a"

export HACC_LD="${HACC_MPI_CXX}"
export HACC_LDFLAGS="${HACC_MPI_CXXFLAGS}"
export HACC_MPI_LDFLAGS="-L${CRAY_MPICH_PREFIX}/lib ${PE_MPICH_GTL_DIR_amd_gfx908} -lmpi ${PE_MPICH_GTL_LIBS_amd_gfx908} -L${ROCM_PATH}/hipfft/lib -lhipfft -L${FFTW_DIR} -lfftw3"

export FFTW_MAJOR_VERSION=3
export FFTW_HOME="${FFTW_ROOT}"

# currently "omp" turns on fftw omp threads
# any other value turns off fftw omp threads, eg. "none"
export FFTW_THREADING=omp


cd ..
#rm -f halo_finder/${HACC_PLATFORM}/libBHForceTree.a
make clean
cd -
make
