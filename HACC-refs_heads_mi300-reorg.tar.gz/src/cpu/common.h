#ifndef COMMON_H
#define COMMON_H

#define MAX_N_INTERP 1024

#endif
