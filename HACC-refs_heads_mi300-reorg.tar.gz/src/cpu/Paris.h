#pragma once

#include <mpi.h>

#include "gpu.h"

class Paris {
  public:
    Paris(const int n[3], const double lo[3], const double hi[3], const int m[3], const int id[3]);
    ~Paris();
    size_t bytes() const { return bytes_; }
    void solve(size_t bytes, double *density, double *potential) const;
  private:
    double ddi_,ddj_,ddk_;
    int idi_,idj_,idk_;
    int mi_,mj_,mk_;
    int nh_,ni_,nj_,nk_;
    int mp_,mq_;
    int idp_,idq_;
    MPI_Comm commI_,commJ_,commK_;
    int dh_,di_,dj_,dk_;
    int dhq_,dip_,djp_,djq_;
    size_t bytes_;
    cufftHandle c2ci_,c2cj_,c2rk_,r2ck_;
#ifdef PARIS_NO_GPU_MPI
    double *ha_, *hb_;
#endif
};
