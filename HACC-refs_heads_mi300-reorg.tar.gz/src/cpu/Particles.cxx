#include "Particles.h"
#include "RCBForceTree.h"
#include "RCOForceTree.h"

#include <omp.h>

int my_posix_memalign(void **memptr, size_t alignment, size_t size) {
  int ret;

  ret = posix_memalign(memptr, alignment, size);
  assert(ret==0);

  return ret;
}

void Particles::forceInterp(uint32_t nInterp) {
  /*
  delete m_fl;
  delete m_fgore;
  */

  m_fgore = new FGridEvalPoly(m_fg);
  m_fl = new ForceLawSR(m_fgore, m_rsm);

  return;
}

void Particles::allocField() {
  const int n = Domain::Ng_local_total()+1;
  const size_t bytes = n*sizeof(float);
  CHECK(hipHostMalloc(&m_field,bytes,hipHostMallocDefault));
  assert(m_field);

  int nglt[3];
  Domain::ng_local_total(nglt);
  int nPot = 1;
  for (int d = 0; d < DIMENSION; d++) nPot *= nglt[d]+4;

  CHECK(hipMalloc(&m_fieldD,nPot*sizeof(float)));
  assert(m_fieldD);
}

Particles::Particles(const Basedata & bdata, MC3Options & options, const size_t parisBytes) :
  m_idArr(NULL),
  m_xArr(NULL),
  m_yArr(NULL),
  m_zArr(NULL),
  m_vxArr(NULL),
  m_vyArr(NULL),
  m_vzArr(NULL),
  m_massArr(nullptr),
  m_phiArr(NULL),
  m_maskArr(NULL),
  m_field(NULL),
  m_fieldD(nullptr),
  m_Np_local_total( 0 ),
  m_alpha(-1.0),
  m_gpscal(-1.0),
  m_nsub(-1),
  m_edge(-1.0),
  m_rsm(-1.0),
  m_fsrrmax(-1.0),
  m_cmsize(-1.0),
  m_openAngle(-1.0),
  m_skipStreamQ(0),
  m_skipKickSRQ(0),
  m_useFastTreeEval(0),
  m_useRCBTree(0),
  m_rcbTreeExtraLevels(0),
  m_rcbTreePPN(0),
  m_rcbTreeTaskPartMin(0),
  m_mpiio(0),
  m_parisBytes(parisBytes)
{
  m_alpha = bdata.alpha();
  m_gpscal = ( static_cast< float >( bdata.ng() ) ) /
    ( static_cast< float >( bdata.np() ) );

  m_nsub = bdata.nsub();
  m_edge = bdata.edge();
  m_rsm = bdata.rsm();
  m_cmsize = bdata.cmsize();
  m_openAngle = bdata.openAngle();

  m_fg = new FGrid();
  m_fsrrmax = m_fg->rmax();

  int nglt[DIMENSION];
  Domain::ng_local_total(nglt);
  m_cm = new CMLite( (int)ceilf(nglt[0]/m_cmsize),
		     (int)ceilf(nglt[1]/m_cmsize),
		     (int)ceilf(nglt[2]/m_cmsize) );

  m_fgore = new FGridEvalFit(m_fg);
  m_fl = new ForceLawSR(m_fgore, m_rsm);

  if(options.interpQ()) {
    forceInterp(options.nInterp());
  }

  if(options.polyQ()) {
    m_fgore = new FGridEvalPoly(m_fg);
    m_fl = new ForceLawSR(m_fgore, m_rsm);
  }

  m_skipStreamQ = options.skipStreamQ();
  m_skipKickSRQ = options.skipKickSRQ();

  m_useFastTreeEval = options.useFastTreeEval();
  m_useRCBTree = options.useRCBTree();
  m_rcbTreeExtraLevels = options.rcbTreeExtraLevels();
  if (!m_rcbTreeExtraLevels) {
    m_rcbTreeExtraLevels = 2;
  }

  m_rcbTreePPN = options.rcbTreePPN();
  if (!m_rcbTreePPN) {
    if (m_useRCBTree == 2 || m_useRCBTree == 5) {
      // default for the monopole mode
      m_rcbTreePPN = 2;
    } else {
      // default for the quadrupole mode
      m_rcbTreePPN = 12;
    }
  }

  m_rcbTreeTaskPartMin = options.rcbTreeTaskPartMin();
  if (!m_rcbTreeTaskPartMin) {
    m_rcbTreeTaskPartMin = 128;
  }

  m_mpiio = options.mpiio();

  CHECK(hipStreamCreate(&m_runStream));
  CHECK(hipStreamCreate(&m_copyStream));
}



Particles::~Particles() {
  CHECK(hipStreamDestroy(m_copyStream));
  CHECK(hipStreamDestroy(m_runStream));
  dropParticles();
  CHECK(hipFree(m_fieldD));
  m_fieldD = nullptr;
  CHECK(hipHostFree(m_field));
  m_field = nullptr;
  delete m_cm;
}



void Particles::dropParticles() {

  CHECK(hipHostFree(m_xArr));
  m_idArr = nullptr;
  m_xArr = m_yArr = m_zArr = m_vxArr = m_vyArr = m_vzArr = m_massArr = m_phiArr = nullptr;
  m_maskArr = nullptr;
  m_gpu.dropParticles();

  m_Np_local_total = 0;

  m_coords_localQ = 0;

  return;
}


void Particles::allocParticles(int Np) {
  dropParticles();
  m_Np_local_total = Np;
  const int n = Np;
  const int ngTotal = Domain::Ng_local_total();
  m_gpu.allocateParticles(n,ngTotal,m_rcbTreePPN,m_parisBytes);

  const long particleBytes = n*(sizeof(long)+8*sizeof(float)+sizeof(MASK_T));
  CHECK(hipHostMalloc(&m_idArr,particleBytes,hipHostMallocDefault));
  m_xArr = reinterpret_cast<float*>(m_idArr+n);
  assert(reinterpret_cast<long*>(m_xArr) == (m_idArr+n));
  m_yArr = m_xArr+n;
  m_zArr = m_yArr+n;
  m_vxArr = m_zArr+n;
  m_vyArr = m_vxArr+n;
  m_vzArr = m_vyArr+n;
  m_massArr = m_vzArr+n;
  m_phiArr = m_massArr+n;
  m_maskArr = reinterpret_cast<MASK_T*>(m_phiArr+n);
  assert(reinterpret_cast<float*>(m_maskArr) == (m_phiArr+n));

  for(int i=0; i<m_Np_local_total; i++) m_massArr[i] = 1.0;

  return;
}



void Particles::copyAllFromVectors(vector<float> **xx,
                                   vector<float> **yy,
                                   vector<float> **zz,
                                   vector<float> **vx,
                                   vector<float> **vy,
                                   vector<float> **vz,
                                   vector<float> **phi,
                                   vector<long> **id,
                                   vector<MASK_T> **mask,
                                   float anow,
                                   int deleteVectorsQ) {
  int Np = (*xx)->size();

  allocParticles(Np);

  std::copy((*xx)->begin(),(*xx)->end(),m_xArr);
  std::copy((*yy)->begin(),(*yy)->end(),m_yArr);
  std::copy((*zz)->begin(),(*zz)->end(),m_zArr);
  std::copy((*vx)->begin(),(*vx)->end(),m_vxArr);
  std::copy((*vy)->begin(),(*vy)->end(),m_vyArr);
  std::copy((*vz)->begin(),(*vz)->end(),m_vzArr);
  for (int i = 0; i < Np; i++) m_massArr[i] = 1.0f;

  std::copy((*phi)->begin(),(*phi)->end(),m_phiArr);
  std::copy((*id)->begin(),(*id)->end(),m_idArr);
  std::copy((*mask)->begin(),(*mask)->end(),m_maskArr);

  if(deleteVectorsQ) {
    free(*xx);
    free(*yy);
    free(*zz);
    free(*vx);
    free(*vy);
    free(*vz);
    free(*phi);
    free(*id);
    free(*mask);
    *xx = *yy = *zz = *vx = *vy = *vz = *phi = nullptr;
    *id = nullptr;
    *mask = nullptr;
  } 

  m_coords_localQ = 0;
  coords_global2local(anow);


  return;
}

//MAYBE SHOULD CHECK BOUNDS FOR EACH DIMENSION
inline int 
Particles::array_index(int xx, 
		       int yy, 
		       int zz, 
		       int ng[DIMENSION], 
		       int lo[DIMENSION],
		       int hi[DIMENSION],
		       int safe) {
/*                       
  int indx, inbounds=1;
  indx = _l_array_index(xx,yy,zz,ng[1],ng[2]);
  inbounds *= (xx >= lo[0]);
  inbounds *= (xx < hi[0]);
  inbounds *= (yy >= lo[1]);
  inbounds *= (yy < hi[1]);
  inbounds *= (zz >= lo[2]);
  inbounds *= (zz < hi[2]);
  return indx*inbounds + safe*(1-inbounds);
*/
  if ( ( xx >= lo[0] ) && ( xx < hi[0] ) && ( yy >= lo[1] ) && ( yy < hi[1] ) && ( zz >= lo[2] ) && ( zz < hi[2] ) )
      return ( xx * ng[1] + yy ) * ng[2] + zz;
  else
      return safe;
}

template <typename T>
static inline void rearrange(const int n, T *__restrict const a, T *__restrict const tmp, const int *__restrict const ix)
{
#pragma omp for
  for (int i = 0; i < n; i++) tmp[i] = a[i];
#pragma omp for
  for (int i = 0; i < n; i++) a[i] = tmp[ix[i]];
}

#define MAX(a, b) (a > b ? a : b)
#define MIN(a, b) (a < b ? a : b)

void Particles::resortParticles() {
  assert(m_coords_localQ == 1);


  int ng[3] = {0,0,0};
  Domain::ng_local_total(ng);
  const int ngTotal = Domain::Ng_local_total();
  std::vector<int> ix(m_Np_local_total);
  std::vector<int> count(ngTotal+1,0);
  std::vector<int> jx(m_Np_local_total);
  std::vector<int> sums(omp_get_max_threads(),0);

  std::vector<long> tmpLong(m_Np_local_total);
  float *const tmpFloat = reinterpret_cast<float*>(tmpLong.data());
  MASK_T *const tmpMask = reinterpret_cast<MASK_T*>(tmpLong.data());

#pragma omp parallel 
  {
#pragma omp for
    for (int p = 0; p < m_Np_local_total; p++) {
      const int i = std::floor(m_xArr[p]);
      const int j = std::floor(m_yArr[p]);
      const int k = std::floor(m_zArr[p]);
      const bool safe = (i >= 0) && (j >= 0) && (k >= 0) && (i < ng[0]) && (j < ng[1]) && (k < ng[2]);
      const int ijk = safe ? (i*ng[1]+j)*ng[2]+k : ngTotal;
      ix[p] = ijk;
      __sync_fetch_and_add_4(count.data()+ijk,1);
    }

#pragma omp master
    {
      m_Np_last = m_Np_local_total-count.back();
    }

    const int t = omp_get_thread_num();
#pragma omp for schedule(static)
    for (int i = 0; i <= ngTotal; i++) sums[t] += count[i];

    int sum = 0;
    for (int i = 0; i < t; i++) sum += sums[i];
#pragma omp for schedule(static)
    for (int i = 0; i <= ngTotal; i++) {
      const int ci = count[i];
      count[i] = sum;
      sum += ci;
    }

#pragma omp for
    for (int p = 0; p < m_Np_local_total; p++) {
      jx[__sync_fetch_and_add_4(count.data()+ix[p],1)] = p;
    }

    rearrange(m_Np_local_total,m_xArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_yArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_zArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_vxArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_vyArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_vzArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_phiArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_massArr,tmpFloat,jx.data());
    rearrange(m_Np_local_total,m_idArr,tmpLong.data(),jx.data());
    rearrange(m_Np_local_total,m_maskArr,tmpMask,jx.data());
  }
}

void Particles::buildChainingMesh() {
  assert(m_coords_localQ == 1);

  int indx;
  int xx, yy, zz;

  //allocated
  int *permArr;
  void *tmpArr;

  //cast
  int *cntArr, *indxArr;
  float *srcPV[N_POSVEL_T], *tmpPV;
  MASK_T *tmpMask;
  long *tmpID;

  int cumulative, tmp, Np, ng[DIMENSION], Ng;
  int zero[DIMENSION] = {0,0,0};

  Np = m_Np_local_total;

  ng[0] = m_cm->ng[0];
  ng[1] = m_cm->ng[1];
  ng[2] = m_cm->ng[2];
  Ng = m_cm->Ng;

  my_posix_memalign( (void **)&permArr, MEM_ALIGN, Np*sizeof(int) );
  my_posix_memalign(&tmpArr,MEM_ALIGN,Np*MAX(sizeof(long),sizeof(float)));
  indxArr = (int *)tmpArr;
  cntArr = (int *)m_field;

  memset(cntArr, 0, (Ng+1)*sizeof(int));
  memset(indxArr, 0, Np*sizeof(int));
  memset(permArr, 0, Np*sizeof(int));

  int nNg = 0;
  for(int i=0; i<Np; i++) {
    xx = static_cast< int >(FLOOR(m_xArr[i]/m_cmsize));
    yy = static_cast< int >(FLOOR(m_yArr[i]/m_cmsize));
    zz = static_cast< int >(FLOOR(m_zArr[i]/m_cmsize));
    indx = array_index(xx, yy, zz, ng, zero, ng, Ng);
    nNg += (indx==Ng);
    indxArr[i] = indx;
    cntArr[indx]++;
  }

  cumulative = Np - nNg;
  m_cm->indxhi[Ng] = Np;
  m_cm->indxlo[Ng] = cumulative;
  for(int i=Ng-1; i>=0; i--) {
    tmp = cntArr[i];
    cntArr[i] = cumulative-tmp;
    m_cm->indxhi[i] = cumulative;
    cumulative -= tmp;
    m_cm->indxlo[i] = cumulative;
  }

  for(int i=0; i<Np; i++) {
    permArr[i] = cntArr[indxArr[i]];
    cntArr[indxArr[i]]++;
  }

  srcPV[0] = m_xArr;
  srcPV[1] = m_yArr;
  srcPV[2] = m_zArr;
  srcPV[3] = m_vxArr;
  srcPV[4] = m_vyArr;
  srcPV[5] = m_vzArr;
  srcPV[6] = m_phiArr;
  srcPV[7] = m_massArr;

  tmpPV = (float *)tmpArr;
  for(int j=0; j<N_POSVEL_T; j++) {
    for(int i=0; i<Np; i++)
      tmpPV[permArr[i]] = srcPV[j][i];
    memcpy(srcPV[j], tmpPV, Np*sizeof(float));
  }

  tmpID = (long *)tmpArr;
  for(int i=0; i<Np; i++)
    tmpID[permArr[i]] = m_idArr[i];
  memcpy(m_idArr, tmpID, Np*sizeof(long));

  tmpMask = (MASK_T *)tmpArr;
  for(int i=0; i<Np; i++)
    tmpMask[permArr[i]] = m_maskArr[i];
  memcpy(m_maskArr, tmpMask, Np*sizeof(MASK_T));

  memset(cntArr, 0, Ng*sizeof(int));
  free(permArr);
  free(tmpArr);

  return;
}

void Particles::cic() {
  assert(m_coords_localQ == 1);

  const int n = Domain::Ng_local_total();
  for (int i = 0; i < n; i++) m_field[i] = 0.0f; 

  int ng[3];
  Domain::ng_local_total(ng);
  const int ni = ng[0];
  const int nj = ng[1];
  const int nk = ng[2];
  const int njk = nj*nk;

  const float c = m_gpscal*m_gpscal*m_gpscal;

  for (int p = 0; p < m_Np_local_total; p++) {
    const float x = m_xArr[p];
    const float y = m_yArr[p];
    const float z = m_zArr[p];

    const float fx = std::floor(x);
    const float fy = std::floor(y);
    const float fz = std::floor(z);

    const int i(fx);
    const int j(fy);
    const int k(fz);

    const int i1 = i+1;
    const int j1 = j+1;
    const int k1 = k+1;

    const float ab = 1.0f+(fx-x);
    const float de = 1.0f+(fy-y);
    const float gh = 1.0f+(fz-z);

    const float cab = c*ab;
    const float cab1 = c*(1.0f-ab);
    const float de1 = 1.0f-de;
    const float gh1 = 1.0f-gh;

    const float cabde = cab*de;
    const float cabde1 = cab*de1;
    const float cab1de = cab1*de;
    const float cab1de1 = cab1*de1;

    assert(i < ni);
    assert(j < nj);
    assert(k < nk);

    assert(i1 >= 0);
    assert(j1 >= 0);
    assert(k1 >= 0);

    const int ijk = (i*nj+j)*nk+k;

    if ((i >= 0) && (j >= 0) && (k >= 0)) m_field[ijk] += cabde*gh;
    if ((i >= 0) && (j >= 0) && (k1 < nk)) m_field[ijk+1] += cabde*gh1;
    if ((i >= 0) && (j1 < nj) && (k >= 0)) m_field[ijk+nk] += cabde1*gh;
    if ((i >= 0) && (j1 < nj) && (k1 < nk)) m_field[ijk+nk+1] += cabde1*gh1;
    if ((i1 < ni) && (j >= 0) && (k >= 0)) m_field[ijk+njk] += cab1de*gh;
    if ((i1 < ni) && (j >= 0) && (k1 < nk)) m_field[ijk+njk+1] += cab1de*gh1;
    if ((i1 < ni) && (j1 < nj) && (k >= 0)) m_field[ijk+njk+nk] += cab1de1*gh;
    if ((i1 < ni) && (j1 < nj) && (k1 < nk)) m_field[ijk+njk+nk+1] += cab1de1*gh1;
  }
}


void Particles::inverse_cic(float tau, float fscal, int comp) {
  assert(m_coords_localQ == 1);

  int ix, iy, iz, ip, jp, kp;
  int nn, ng[DIMENSION], Ng, np;
  int zero[DIMENSION] = {0,0,0};
  float xx, yy, zz;
  float ab, de, gh;
  float f;
  float *x, *y, *z;
  float *vels[DIMENSION+1];
  float *grad_phi;
  int safe;

  Domain::ng_local_total(ng);
  Ng = Domain::Ng_local_total();
  np = m_Np_local_total;

  x = &m_xArr[0];
  y = &m_yArr[0];
  z = &m_zArr[0];

  vels[0] = &m_vxArr[0];
  vels[1] = &m_vyArr[0];
  vels[2] = &m_vzArr[0];

  vels[3] = &m_phiArr[0];

  grad_phi = m_field;
  safe = Ng;
  grad_phi[safe] = 0.0;

#ifdef _OPENMP
#pragma omp parallel for private(xx,yy,zz,ix,iy,iz,ip,jp,kp,ab,de,gh,f)
#endif
  for(nn=0; nn < np; nn++) {
    xx = x[nn];
    yy = y[nn];
    zz = z[nn];

    ix = static_cast< int >(FLOOR(xx));
    iy = static_cast< int >(FLOOR(yy));
    iz = static_cast< int >(FLOOR(zz));

    ip = ix+1;
    jp = iy+1;
    kp = iz+1;

    ab = 1.0 + (ix-xx);
    de = 1.0 + (iy-yy);
    gh = 1.0 + (iz-zz);

    f = 0;

    f += grad_phi[array_index(ix,iy,iz,ng,zero,ng,safe)]*ab*de*gh;
    f += grad_phi[array_index(ix,jp,iz,ng,zero,ng,safe)]*ab*(1.0-de)*gh;
    f += grad_phi[array_index(ix,jp,kp,ng,zero,ng,safe)]*ab*(1.0-de)*(1.0-gh);
    f += grad_phi[array_index(ix,iy,kp,ng,zero,ng,safe)]*ab*de*(1.0-gh);
    f += grad_phi[array_index(ip,iy,kp,ng,zero,ng,safe)]*(1.0-ab)*de*(1.0-gh);
    f += grad_phi[array_index(ip,jp,kp,ng,zero,ng,safe)]*(1.0-ab)*(1.0-de)*(1.0-gh);
    f += grad_phi[array_index(ip,jp,iz,ng,zero,ng,safe)]*(1.0-ab)*(1.0-de)*gh;
    f += grad_phi[array_index(ip,iy,iz,ng,zero,ng,safe)]*(1.0-ab)*de*gh;

    vels[comp][nn] += f*fscal*tau;
  }

  return;
}



void Particles::inverse_cic_potential() {
  assert(m_coords_localQ == 1);

  //set m_phiArr=0
  memset(m_phiArr, 0, m_Np_local_total*sizeof(float));

  //call inverse_cic
  inverse_cic(1.0, 1.0, 3);

  return;
}



void Particles::map1(float pp, float tau, float adot) {
  assert(m_coords_localQ == 1);

  float *x, *y, *z, *vx, *vy, *vz;
  int i;

  x = m_xArr;
  y = m_yArr;
  z = m_zArr;
  vx = m_vxArr;
  vy = m_vyArr;
  vz = m_vzArr;

  const float pf = powf(pp, (1.0 + 1.0 / m_alpha) );
  const float prefactor = 1.0 / (m_alpha * adot * pf);

#ifdef _OPENMP
#pragma omp parallel for
#endif
  for (i = 0; i < m_Np_local_total; i++) {
    x[i] = x[i] + prefactor * tau * vx[i];
    y[i] = y[i] + prefactor * tau * vy[i];
    z[i] = z[i] + prefactor * tau * vz[i];
  }

  return;
}



void Particles::coords_global2local(float anow) {
  int i;
  float phys2grid_pos, phys2grid_vel, pre_vel;
  int corner[DIMENSION];

  if(m_coords_localQ == 0) {

    phys2grid_pos = Domain::phys2grid_pos();
    phys2grid_vel = Domain::phys2grid_vel();
    Domain::corner_grid_total(corner);
    
    pre_vel = phys2grid_vel*anow*anow;
    
    for(i=0; i<m_Np_local_total; i++) {
      m_xArr[i] *= phys2grid_pos;
      m_xArr[i] -= corner[0];
      
      m_yArr[i] *= phys2grid_pos;
      m_yArr[i] -= corner[1];
      
      m_zArr[i] *= phys2grid_pos;
      m_zArr[i] -= corner[2];
      
      m_vxArr[i] *= pre_vel;
      m_vyArr[i] *= pre_vel;
      m_vzArr[i] *= pre_vel;
    }

    m_coords_localQ = 1;
  }

  return;
}



void Particles::coords_local2global(float anow) {
  int i;
  float grid2phys_pos, grid2phys_vel, pre_vel;
  int corner[DIMENSION];

  if(m_coords_localQ == 1) {

    grid2phys_pos = Domain::grid2phys_pos();
    grid2phys_vel = Domain::grid2phys_vel();
    Domain::corner_grid_total(corner);
    
    pre_vel = grid2phys_vel/anow/anow;
    
    for(i=0; i<m_Np_local_total; i++) {
      m_xArr[i] += corner[0];
      m_xArr[i] *= grid2phys_pos;
      
      m_yArr[i] += corner[1];
      m_yArr[i] *= grid2phys_pos;
      
      m_zArr[i] += corner[2];
      m_zArr[i] *= grid2phys_pos;
      
      m_vxArr[i] *= pre_vel;
      m_vyArr[i] *= pre_vel;
      m_vzArr[i] *= pre_vel;
    }

    m_coords_localQ = 0;
  }

  return;
}



int Particles::Np_local_alive() {
  assert(m_coords_localQ == 1);

  int npla=0, i, ngla[DIMENSION];
  float lo, hi[DIMENSION];

  lo = 1.0*Domain::ng_overload();
  Domain::ng_local_alive(ngla);
  for(i=0; i<DIMENSION; i++)
    hi[i] = lo + 1.0*ngla[i];

  for(i=0; i<m_Np_local_total; i++) {
    npla += (m_xArr[i]>=lo)*(m_xArr[i]<hi[0])*(m_yArr[i]>=lo)*(m_yArr[i]<hi[1])*(m_zArr[i]>=lo)*(m_zArr[i]<hi[2]);
  }

  return npla;
}



void Particles::writeAliveHCosmo( const char *outName, float anow ) {
  int i;
  int Npla = Np_local_alive();

  coords_local2global(anow);

  float ca[DIMENSION];
  Domain::corner_phys_alive(ca);
  float rla[DIMENSION];
  Domain::rL_local_alive(rla);
  float lo[DIMENSION], hi[DIMENSION];
  for(i=0; i<DIMENSION; i++) {
    lo[i] = ca[i];
    hi[i] = ca[i] + rla[i];
  }

  if(m_mpiio) {
    assert(sizeof(long) == 8);

    vector<float> *xx = new vector<float>;
    vector<float> *vx = new vector<float>;
    vector<float> *yy = new vector<float>;
    vector<float> *vy = new vector<float>;
    vector<float> *zz = new vector<float>;
    vector<float> *vz = new vector<float>;
    vector<float> *phi = new vector<float>;
    vector<MASK_T> *mask = new vector<MASK_T>;
    vector<long> *id = new vector<long>;

    copyAliveIntoVectors(xx, yy, zz, vx, vy, vz,
			 phi, id, mask, anow, 
			 Npla, 0);

    RestartIO *wr = new RestartIO(IO_WRITE_RESTART, (char *)outName, MPI_COMM_WORLD);
    wr->WriteRestart(Npla, 
		     (float *)&(xx[0]),
		     (float *)&(yy[0]),
		     (float *)&(zz[0]),
		     (float *)&(vx[0]),
		     (float *)&(vy[0]),
		     (float *)&(vz[0]),
		     (float *)&(phi[0]),
		     (long *)&(id[0]),
		     (MASK_T *)&(mask[0]));
    delete wr;

    delete xx;
    delete vx;
    delete yy;
    delete vy;
    delete zz;
    delete vz;
    delete phi;
    delete mask;
    delete id;
  } else {

#ifdef SINGLE_RANK_OUTPUT
    if(Partition::getMyProc() == 0) {
#endif
      
      FILE *outFile = fopen(outName, "wb");
      for (i = 0; i < m_Np_local_total; i++) {
	if( (m_xArr[i]>=lo[0])*(m_xArr[i]<hi[0])*
	    (m_yArr[i]>=lo[1])*(m_yArr[i]<hi[1])*
	    (m_zArr[i]>=lo[2])*(m_zArr[i]<hi[2]) ) {
	  fwrite(&m_xArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_vxArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_yArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_vyArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_zArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_vzArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_phiArr[i], sizeof(float), 1, outFile);
	  fwrite(&m_idArr[i], sizeof(long), 1, outFile);
	}
      }
      fclose(outFile); 
      
#ifdef SINGLE_RANK_OUTPUT
    }
#endif

  }

  coords_global2local(anow);

  return;
}



void Particles::copyAliveIntoVectors(vector<float> *xx,
                                     vector<float> *yy,
                                     vector<float> *zz,
                                     vector<float> *vx,
                                     vector<float> *vy,
                                     vector<float> *vz,
                                     vector<float> *phi,
                                     vector<long> *id,
                                     vector<MASK_T> *mask,
                                     float anow,
                                     int npr,
                                     int dropParticlesQ)
{
  coords_local2global(anow);

  xx->reserve(npr);
  yy->reserve(npr);
  zz->reserve(npr);
  vx->reserve(npr);
  vy->reserve(npr);
  vz->reserve(npr);
  phi->reserve(npr);
  id->reserve(npr);
  mask->reserve(npr);

  float ca[DIMENSION];
  Domain::corner_phys_alive(ca);
  float rla[DIMENSION];
  Domain::rL_local_alive(rla);
  float lo[DIMENSION], hi[DIMENSION];
  for(int i=0; i<DIMENSION; i++) {
    lo[i] = ca[i];
    hi[i] = ca[i] + rla[i];
  }

  for (int i = 0; i < m_Np_local_total; i++) {
    const float x = m_xArr[i];
    const float y = m_yArr[i];
    const float z = m_zArr[i];
    if ((x >= lo[0]) && (x < hi[0]) && (y >= lo[1]) && (y < hi[1]) && (z >= lo[2]) && (z < hi[2])) {
      xx->push_back(x);
      yy->push_back(y);
      zz->push_back(z);
      vx->push_back(m_vxArr[i]);
      vy->push_back(m_vyArr[i]);
      vz->push_back(m_vzArr[i]);
      phi->push_back(m_phiArr[i]);
      mask->push_back(m_maskArr[i]);
    }
  }

  if(dropParticlesQ) dropParticles();
  else coords_global2local(anow);

  return;
}



void Particles::writeRawAscii( const char *fname )
{
  FILE* out_fp;
  out_fp = fopen(fname, "w");

  int i;
  for (i = 0; i < m_Np_local_total; i++) {
    fprintf(out_fp, "%f %f %f %f %f %f %f %ld\n",
	    m_xArr[i],
	    m_yArr[i],
	    m_zArr[i],
	    m_vxArr[i],
	    m_vyArr[i],
	    m_vzArr[i],
	    m_phiArr[i],
	    m_idArr[i]);
  }
  fclose(out_fp);

  return;
}



void Particles::writeRestart( const char *outName )
{
  assert(m_coords_localQ == 1);

  if(m_mpiio) {
    assert(sizeof(long) == 8);
    RestartIO *wr = new RestartIO(IO_WRITE_RESTART, (char *)outName, MPI_COMM_WORLD);
    int Nplt = m_Np_local_total;
    wr->WriteRestart(Nplt, m_xArr, m_yArr, m_zArr, m_vxArr, m_vyArr, m_vzArr, m_phiArr, m_idArr, m_maskArr);
    delete wr;
  } else {
    FILE *outFile = fopen(outName, "wb");
    fwrite(&m_Np_local_total, sizeof(int), 1, outFile);
    fwrite(&m_xArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_vxArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_yArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_vyArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_zArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_vzArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_phiArr[0], sizeof(float), m_Np_local_total, outFile);
    fwrite(&m_idArr[0], sizeof(long), m_Np_local_total, outFile);
    fwrite(&m_maskArr[0], sizeof(MASK_T), m_Np_local_total, outFile);
    fclose(outFile); 
  }

  return;
}



void Particles::readRestart( const char *inName ) {

  if(m_mpiio) {
    assert(!"MPI-IO not supported");
  } else {
    FILE *inFile = fopen(inName, "rb");
    int Np;
    fread(&Np, sizeof(int), 1, inFile);
    allocParticles(Np);
    fread(&m_xArr[0], sizeof(float), Np, inFile);
    fread(&m_vxArr[0], sizeof(float), Np, inFile);
    fread(&m_yArr[0], sizeof(float), Np, inFile);
    fread(&m_vyArr[0], sizeof(float), Np, inFile);
    fread(&m_zArr[0], sizeof(float), Np, inFile);
    fread(&m_vzArr[0], sizeof(float), Np, inFile);
    fread(&m_phiArr[0], sizeof(float), Np, inFile);
    fread(&m_idArr[0], sizeof(long), Np, inFile);
    fread(&m_maskArr[0], sizeof(MASK_T), Np, inFile);  
    fclose(inFile);
  }

  for(int i=0; i<m_Np_local_total; i++)
    m_massArr[i] = 1.0;

  m_coords_localQ = 1;

  return;
}



vector<unsigned int>* Particles::aliveIndices() {
  assert(m_coords_localQ == 1);

  vector<unsigned int> *ai = new vector<unsigned int>;
  ai->reserve(Np_local_alive());

  int ngla[DIMENSION];
  float lo, hi[DIMENSION];

  lo = 1.0*Domain::ng_overload();
  Domain::ng_local_alive(ngla);
  for(int i=0; i<DIMENSION; i++)
    hi[i] = lo + 1.0*ngla[i];

  for(int i=0; i<m_Np_local_total; i++)
    if( (m_xArr[i]>=lo)*(m_xArr[i]<hi[0])*(m_yArr[i]>=lo)*(m_yArr[i]<hi[1])*(m_zArr[i]>=lo)*(m_zArr[i]<hi[2]) )
      ai->push_back(i);

  return ai;
}


void Particles::subCycle(TimeStepper *gts) {
  // SimpleTimings::TimerRef t_cm = SimpleTimings::getTimer("cm");
  // SimpleTimings::TimerRef t_map1 = SimpleTimings::getTimer("map1");

  double stepFraction = 1.0/m_nsub;

  for(int step=0; step < m_nsub; step++) {
    //half stream
    // SimpleTimings::startTimer(t_map1);
    if(!m_skipStreamQ) {
      map1d(gts->pp(), stepFraction*gts->tau2(), gts->adot());
    }
    // SimpleTimings::stopTimerStats(t_map1);

    //kick
    if(!m_skipKickSRQ) {
      map2(gts, stepFraction);
    }

    //half stream
    // SimpleTimings::startTimer(t_map1);
    if(!m_skipStreamQ) {
      map1d(gts->pp(), stepFraction*gts->tau2(), gts->adot());
    }
    // SimpleTimings::stopTimerStats(t_map1);
    
  }
  return;
}



void Particles::map2(TimeStepper *ts, TS_FLOAT stepFraction) {
  int Np = m_Np_local_total;

  //local subvolume dimensions in grid units
  int nglt[DIMENSION];
  Domain::ng_local_total(nglt);

  //limits for BH tree build
  float ngltree[DIMENSION];
  ngltree[0] = 1.0*MAX( MAX( nglt[0], nglt[1] ), nglt[2] );
  ngltree[2] = ngltree[1] = ngltree[0];
  float zero[DIMENSION] = {0.0, 0.0, 0.0};

  //limits for particle velocity updates
  float xlo, ylo, zlo, xhi, yhi, zhi;
  xlo = m_edge;
  ylo = m_edge;
  zlo = m_edge;
  xhi = 1.0*nglt[0] - m_edge;
  yhi = 1.0*nglt[1] - m_edge;
  zhi = 1.0*nglt[2] - m_edge;

  float lo[DIMENSION] = { xlo, ylo, zlo };
  float hi[DIMENSION] = { xhi, yhi, zhi };

  float divscal, pi, c;
  divscal = m_gpscal*m_gpscal*m_gpscal;
  pi = 4.0*atanf(1.0);
  c = divscal/4.0/pi*ts->fscal()*ts->tau()*stepFraction;



  // SimpleTimings::TimerRef t_map2_srt = SimpleTimings::getTimer("map2s");
  // SimpleTimings::TimerRef t_map2_bld = SimpleTimings::getTimer("map2b");
  // SimpleTimings::TimerRef t_map2_wlk = SimpleTimings::getTimer("map2w");

  //move out of bounds particles to end of arrays
  // SimpleTimings::startTimer(t_map2_srt);
  resortParticlesD();
  // SimpleTimings::stopTimerStats(t_map2_srt);


  //only use tree for in bounds particlesx
  Np = m_Np_last;

#if 0
  for (int i = 0; i < Np; ++i) {
    printf("%d: %f %f %f\n", i, m_xArr[i], m_yArr[i], m_zArr[i]);
  }
#endif


  assert(m_useRCBTree == 2);
  // SimpleTimings::startTimer(t_map2_bld);
  RCBMonopoleForceTree(zero,
                       ngltree,
                       lo, hi,
                       Np,
                       m_gpu,
                       1.0,
                       m_fsrrmax,
                       m_rsm,
                       m_openAngle,
                       m_rcbTreePPN,
                       m_rcbTreeExtraLevels,
                       m_rcbTreeTaskPartMin,
                       m_fl,
                       c);
  // SimpleTimings::stopTimerStats(t_map2_bld);
}



void Particles::subCycleCM(TimeStepper *gts) {

  return;
}



void Particles::map2CM(TimeStepper *ts, TS_FLOAT stepFraction) {
  
  return;
}

void Particles::copyFieldFromDevice()
{
  const size_t bytes = (Domain::Ng_local_total()+1)*sizeof(float);
  CHECK(hipMemcpy(m_field,m_fieldD,bytes,hipMemcpyDeviceToHost));
}

void Particles::copyFromDevice()
{
  CHECK(hipMemcpy(m_xArr,m_gpu.xx,m_gpu.particleBytes,hipMemcpyDeviceToHost));
}

void Particles::copyToDevice()
{
  CHECK(hipMemcpyAsync(m_gpu.xx,m_xArr,m_gpu.particleBytes,hipMemcpyHostToDevice,0));
}

CMLite::CMLite(int ngx, int ngy, int ngz) {
  ng[0] = ngx;
  ng[1] = ngy;
  ng[2] = ngz;
  Ng = ngx*ngy*ngz;
  indxlo = new int[Ng+1];
  indxhi = new int[Ng+1];
}


CMLite::~CMLite() {
  delete [] indxlo;
  delete [] indxhi;
}
