#!/bin/bash
module restore -s PrgEnv-cray 
module load cray-fftw rocm
module list

#export HIP_PLATFORM=hcc
export MPI_HOME=$(dirname $(dirname $(which mpicc)))
echo $MPI_HOME

export HACC_PLATFORM="redwood"
export HACC_OBJDIR="${HACC_PLATFORM}"

ompflg="-fopenmp"

export HACC_CC=cc
export HACC_CXX=CC
export HACC_MPI_CC=$HACC_CC
export HACC_MPI_CXX=$HACC_CXX
export HACC_GPU_CXX=hipcc

export HACC_CFLAGS="-g -Ofast ${ompflg} -fsave-loopmark -Wall"

export HACC_CXXFLAGS="${HACC_CFLAGS} -std=c++17 $(hipconfig -C)"
export HACC_MPI_CFLAGS=$HACC_CFLAGS
export HACC_MPI_CXXFLAGS=$HACC_CXXFLAGS
export HACC_GPU_CXXFLAGS="-g -Ofast -std=c++17 -Wall --amdgpu-target=gfx906,gfx908 -I${ROCM_PATH}/hipcub/include -I${ROCM_PATH}/rocprim/include -I${MPI_HOME}/include"

export HACC_LD="${HACC_MPI_CXX}"
export HACC_LDFLAGS="${HACC_MPI_CXXFLAGS}"
export HACC_MPI_LDFLAGS="-L${ROCM_PATH}/lib -lamdhip64"

export FFTW_MAJOR_VERSION=3

# currently "omp" turns on fftw omp threads
# any other value turns off fftw omp threads, eg. "none"
export FFTW_THREADING=omp

use_essl=no
if [ "x$use_essl" = xyes ]; then
export FFTW_WRAPPER=essl
export ESSL_LIBDIR=/home/morozov/ESSL5.1.1-20120305 
export XLF_LIBDIR=${COMPILER_PATH}/xlf/bg/14.1/bglib64
root=/gpfs/mira-home/morozov/Work/ALCF3/CoralApps/HACC/src/essl_fftw

export FFTW_HOME=${root}
export FFTW_INCLUDE=${root}/include
export CPATH=${root}/include:${CPATH}
if [ -f ${root}/bglib64 ] 
then
export LD_LIBRARY_PATH=${root}/bglib64:${LD_LIBRARY_PATH}
else
export LD_LIBRARY_PATH=${root}/bglib:${LD_LIBRARY_PATH}
fi

else

root=${FFTW_ROOT}

export FFTW_HOME=${root}
export FFTW_INCLUDE=${root}/include
export CPATH=${root}/include:${CPATH}
if [ -f ${root}/lib64 ] 
then
export LD_LIBRARY_PATH=${root}/lib64:${LD_LIBRARY_PATH}
else
export LD_LIBRARY_PATH=${root}/lib:${LD_LIBRARY_PATH}
fi
export INFOPATH=${root}/share/info:${INFOPATH}
export MANPATH=${root}/share/man:$MANPATH
export PATH=${root}/bin:${PATH}

fi

cd ../halo_finder/redwood
rm -f RCBForceTree* libBHForceTree.a
cd -
cd ..
make clean
cd -
make
