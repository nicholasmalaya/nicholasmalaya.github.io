#!/bin/bash
module swap cray-mpich/8.1.12.124
module load rocm
module load craype-accel-amd-gfx90a
module load cray-fftw
module list

#export PE_MPICH_GTL_DIR_amd_gfx90a=${PE_MPICH_GTL_DIR_amd_gfx908}
#export PE_MPICH_GTL_LIBS_amd_gfx90a=${PE_MPICH_GTL_LIBS_amd_gfx908}

export HACC_PLATFORM=${HOSTNAME}
export HACC_OBJDIR="${HACC_PLATFORM}"

ompflg="-fopenmp"

export HACC_CC=cc
export HACC_CXX=CC
export HACC_MPI_CC=$HACC_CC
export HACC_MPI_CXX=$HACC_CXX
export HACC_GPU_CXX=hipcc

#export HACC_CFLAGS="-g -Ofast ${ompflg} -fsave-loopmark -Wall"
export HACC_CFLAGS="-g -Ofast ${ompflg}"

export HACC_CXXFLAGS="-DO_HIP -DPARIS_HACC ${HACC_CFLAGS} -std=c++17 $(hipconfig -C) -I${ROCM_PATH}/hipfft/include"
export HACC_MPI_CFLAGS=$HACC_CFLAGS
export HACC_MPI_CXXFLAGS=$HACC_CXXFLAGS
export HACC_GPU_CXXFLAGS="-Wall -Wno-unused-result -DO_HIP -DPARIS_HACC -g -Ofast -std=c++17 --amdgpu-target=gfx90a -I${CRAY_MPICH_PREFIX}/include -I${ROCM_PATH}/hipfft/include"

export HACC_LD="${HACC_MPI_CXX}"
export HACC_LDFLAGS="${HACC_MPI_CXXFLAGS}"
export HACC_MPI_LDFLAGS="-L${ROCM_PATH}/lib -lamdhip64 -lhsa-runtime64 -lhipfft"

export FFTW_MAJOR_VERSION=3

# currently "omp" turns on fftw omp threads
# any other value turns off fftw omp threads, eg. "none"
export FFTW_THREADING=omp

use_essl=no
if [ "x$use_essl" = xyes ]; then
export FFTW_WRAPPER=essl
export ESSL_LIBDIR=/home/morozov/ESSL5.1.1-20120305 
export XLF_LIBDIR=${COMPILER_PATH}/xlf/bg/14.1/bglib64
root=/gpfs/mira-home/morozov/Work/ALCF3/CoralApps/HACC/src/essl_fftw

export FFTW_HOME=${root}
export FFTW_INCLUDE=${root}/include
export CPATH=${root}/include:${CPATH}
if [ -f ${root}/bglib64 ] 
then
export LD_LIBRARY_PATH=${root}/bglib64:${LD_LIBRARY_PATH}
else
export LD_LIBRARY_PATH=${root}/bglib:${LD_LIBRARY_PATH}
fi

else

root=${FFTW_DIR}/..

export FFTW_HOME=${root}
export FFTW_INCLUDE=${root}/include
export CPATH=${root}/include:${CPATH}
if [ -f ${root}/lib64 ] 
then
export LD_LIBRARY_PATH=${root}/lib64:${LD_LIBRARY_PATH}
else
export LD_LIBRARY_PATH=${root}/lib:${LD_LIBRARY_PATH}
fi
export INFOPATH=${root}/share/info:${INFOPATH}
export MANPATH=${root}/share/man:$MANPATH
export PATH=${root}/bin:${PATH}

fi

cd ..
#rm -f halo_finder/${HOSTNAME}/libBHForceTree.a
make clean
cd -
make
