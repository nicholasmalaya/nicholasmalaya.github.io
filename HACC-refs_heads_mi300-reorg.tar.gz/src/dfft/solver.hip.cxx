#include "solver.hpp"
#include "gpu.h"

#include <cstdio>

void SolverBase::backwardSolveGradient(const int axis, complex_t *const grad_phi, complex_t *const gradPhiD)
{
  kspace_solve_gradient(axis, &m_buf2[0], &m_buf1[0]);    // buf2 --> buf1
  fftw_execute(m_plan_b_z);                               // buf1 --> buf3
  distribution_2_to_3(&m_buf3[0], &m_buf1[0], &m_d, 2);   // buf3 --> buf1
  distribution_3_to_2(&m_buf1[0], &m_buf3[0], &m_d, 1);   // buf1 --> buf3
  fftw_execute(m_plan_b_y);                               // buf3 --> buf1
  distribution_2_to_3(&m_buf1[0], &m_buf3[0], &m_d, 1);   // buf1 --> buf3
  distribution_3_to_2(&m_buf3[0], &m_buf1[0], &m_d, 0);   // buf3 --> buf1
  //fftw_execute(m_plan_b_x);                               // buf1 --> buf3
  //distribution_2_to_3(&m_buf3[0], grad_phi, &m_d, 0);     // buf3 --> grad_phi
  CHECK(hipMemcpy(m_buf1D,m_buf1,sizeof(complex_t)*local_size(),hipMemcpyHostToDevice));
  hipfftDoubleComplex *const buf1D = reinterpret_cast<hipfftDoubleComplex*>(m_buf1D);
  hipfftDoubleComplex *const buf3D = reinterpret_cast<hipfftDoubleComplex*>(m_buf3D);
  CHECK(hipfftExecZ2Z(m_planBX,buf1D,buf3D,HIPFFT_BACKWARD));
  distribution2to3(m_buf3D,gradPhiD,m_d,0);
}

