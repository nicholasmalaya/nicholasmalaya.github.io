#!/bin/bash
set -eox pipefail

# Check for proper call
if [ -z "$4" ];then
  echo "Correct Useage: ./run.sh <np> <nt> <ngpu> <misc>"
  echo "where: "
  echo "      np: number of particles"
  echo "      nt: number of threads per rank"
  echo "      ngpu: number of GPUs (1 rank per GPU)"
  echo "      misc: 1 to profile with rocprof. 0 to not collect profile"
  echo "      runOpts: "
  echo "        * 1 to collect trace with rocprof"
  echo "        * 2 to run with gdb"
  echo "        * 3 to run on cluster with slurm (redwood)"
  #echo "        * 4 to collect counters with rocprof"
  echo "        * 0 otherwise"
  exit 1
fi

APP_NAME=HACC-CORAL2

# Variables for pretty colored output
GREEN='\033[0;32m'
NC='\033[0m' # No Color

#Check if MPI Env Var is set
if [ -z ${MPI_HOME} ]; then
  echo "MPI_HOME is unset. Please set to location of MPI install";
  exit
else 
  echo "var is set to '${MPI_HOME}'";
fi

#Check if ROCm Env Var is set
if [ -z ${ROCM_PATH} ]; then
  echo "ROCM_PATH is unset. Please set to location of ROCm install";
  exit
else 
  echo "var is set to '${ROCM_PATH}'";
fi

export OMP_NUM_THREADS=$2
DIR="out.$1.1x$2.$(date +"%Y-%m-%d_%H-%M-%S")"
mkdir -p $DIR
cd $DIR

export LD_LIBRARY_PATH=${MPI_HOME}/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=${ROCM_PATH}/llvm/lib:$LD_LIBRARY_PATH

# Set run params for requested number of GPUs
if [[ "$3" == 1 ]];then
  x=1;y=1;z=1
elif [[ "$3" == 2 ]];then
  x=2;y=1;z=1
elif [[ "$3" == 4 ]];then
  x=2;y=2;z=1
elif [[ "$3" == 8 ]];then
  x=2;y=2;z=2
fi

# Set rocprof path if profiling requested
if [[ "$4" == 1 ]];then
  ROCPROF="$ROCM_PATH/bin/rocprof --hsa-trace --sys-trace --roctx-trace --hip-trace --stats"
  #ROCPROF="/home/amd/rachida/rocprofiler/bin/rpl_run.sh --roctx-trace --hip-trace --stats"
fi

# Set rocprof path if profiling requested
if [[ "$4" == 4 ]];then
  ROCPROF="$ROCM_PATH/bin/rocprof -i ../profiling/counters.txt --timestamp on"
fi

# Set gdb path if debugging requested
if [[ "$4" == 2 ]];then
  GDB="$ROCM_PATH/bin/rocgdb --args"
fi

# Set srun if running in slurm
if [[ "$4" == 3 ]];then
  export MV2_USE_CUDA=1
  export MV2_ENABLE_AFFINITY=0
  MPI_RUN="srun --exclusive -p amdMI100 -N1 -n$3 -c$2"
else
  MPI_RUN="${MPI_HOME}/bin/mpirun -n $3 --bind-to none"
fi

# Perform the HACC run
echo "${ROCPROF} ${MPI_RUN} ../src/cpu/redwood/hacc_tpm ../redwood/$1 ../cmbM000.tf m000 INIT ALL_TO_ALL -w -R -N 512 -t ${x}x${y}x${z} -T 32 |& tee screenOutput.txt"
${ROCPROF} ${MPI_RUN} ${GDB} ../src/cpu/redwood/hacc_tpm ../redwood/$1 ../cmbM000.tf m000 INIT ALL_TO_ALL -w -R -N 512 -t ${x}x${y}x${z} -T 32 |& tee screenOutput.txt &
wait

echo "Starting FOM calculation"

# Compute FOM
particles=$(( $1 * $1 * $1))
temp=($(cat screenOutput.txt | grep step | tail -1))
runtime=$(echo "${temp[2]}" | awk -F"E" 'BEGIN{OFMT="%10.10f"} {print $1 * (10 ^ $2)}')
value=$(bc <<< "scale = 2; ($particles / $runtime)")
metric=FOM
printf "${GREEN}FOM: $value $metric ${NC}\n"

# Validate the HACC run
 ../validation/validation.sh ../validation/np$1/m000.pk.ini ../validation/np$1/m000.pk.fin m000.pk.ini m000.pk.fin |& tee validationOutput.txt

# Collect System Information
SERVER_ADDRESS=http://pavii1.amd.com:8086/write?db=jenkins   # Address is hardcoded and passed in from Jenkinsfile template
OS=$(lsb_release -d | cut -c14- | tr -d '[:space:]')
ROCm=$(cat $ROCM_PATH/.info/version)             # For performance tracking (publish)
REPO=$(basename `git rev-parse --show-toplevel`)
BRANCH=$(git rev-parse --abbrev-ref HEAD)
COMMIT=$(git rev-parse --short HEAD)           # For performance tracking (publish)
NODE=$(hostname)             # For performance tracking (publish)
CPU=$(cat /proc/cpuinfo | grep -m 1 'model name' | cut -c14- | tr -d '[:space:]')
temp=($(rocminfo | grep -m 1 gfx))
GPU=${temp[1]}
MPI=$MPI_HOME

# Collect HACC Run Information
nt=$2
np=$1
temp=($(cat ../redwood/$1 | grep nstep))
nstep=${temp[0]}
temp=($(cat ../redwood/$1 | grep nsub))
nsub=${temp[0]}
ngpu=$3
temp=($(cat validationOutput.txt | grep -E "(PASSED|FAILED)"))
valid=$(echo ${temp[3]} | sed 's/\x1B\[[0-9;]\{1,\}[A-Za-z]//g')  #removes color

# Send the result to the database
#if [ "$valid" == "PASSED" ]; then
  echo "Sending result to results database"
  # If running with slurm on redwood
  if [[ "$4" == 3 ]]; then
    ROCm=$(cat $ROCM_PATH/.info/version-dev)             # For performance tracking (publish)
    echo "#!/bin/bash" > database-transmission.sh
    echo -e "curl -i -XPOST "$SERVER_ADDRESS" --data-binary \
    "$APP_NAME,ROCm=$ROCm,OS=$OS,Node=$NODE,Repo=$REPO,Branch=$BRANCH,Commit=$COMMIT,cpu=$CPU,gpu=$GPU,mpi=$MPI,nt=$nt,np=$np,nstep=$nstep,nsub=$nsub,ngpu=$ngpu,valid=$valid $metric=$value"" >> database-transmission.sh
  else
    echo "curl -i -XPOST "$SERVER_ADDRESS" --data-binary \
    "$APP_NAME,ROCm=$ROCm,OS=$OS,Node=$NODE,Repo=$REPO,Branch=$BRANCH,Commit=$COMMIT,cpu=$CPU,gpu=$GPU,mpi=$MPI,nt=$nt,np=$np,nstep=$nstep,nsub=$nsub,ngpu=$ngpu,valid=$valid $metric=$value""
    curl -i -XPOST "$SERVER_ADDRESS" --data-binary \
    "$APP_NAME,ROCm=$ROCm,OS=$OS,Node=$NODE,Repo=$REPO,Branch=$BRANCH,Commit=$COMMIT,cpu=$CPU,gpu=$GPU,mpi=$MPI,nt=$nt,np=$np,nstep=$nstep,nsub=$nsub,ngpu=$ngpu,valid=$valid $metric=$value"
  fi
#else
#  echo "Failed validation so not sending results to database"
#fi
